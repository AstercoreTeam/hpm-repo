// ===================================================================================
// USB Handler for CH552
// ===================================================================================

#include "usb_handler.h"

// ===================================================================================
// Variables
// ===================================================================================
volatile uint8_t  USB_SetupReq, USB_SetupTyp, USB_Config, USB_Addr;
volatile uint16_t USB_SetupLen;
volatile unsigned char USB_ENUM_OK;
__code uint8_t*   USB_pDescr;

// ===================================================================================
// Setup/Reset Endpoints
// ===================================================================================
void USB_EP_init(void) {
  // CH552：UEP0_DMA 是 16 位 SFR
  UEP0_DMA = (uint16_t)EP0_buffer;

  UEP0_CTRL   = UEP_R_RES_ACK | UEP_T_RES_NAK;
  UEP0_T_LEN  = 0;
  USB_ENUM_OK = 0;

  #ifdef USB_INIT_endpoints
  USB_INIT_endpoints();
  #endif
}

// ===================================================================================
// USB Init Function
// ===================================================================================
void USB_init(void) {
  USB_CTRL    = bUC_DEV_PU_EN | bUC_INT_BUSY | bUC_DMA_EN;
  UDEV_CTRL   = bUD_DP_PD_DIS | bUD_DM_PD_DIS | bUD_PORT_EN;

  USB_EP_init();

  USB_INT_EN  = bUIE_SUSPEND | bUIE_TRANSFER | bUIE_BUS_RST;
  USB_INT_FG  = 0x1f;
  IE_USB      = 1;
  EA          = 1;
}

// ===================================================================================
// Fast Copy Function
// ===================================================================================
#pragma callee_saves USB_EP0_copyDescr
void USB_EP0_copyDescr(uint8_t len) {
  len;
  __asm
    push acc
    push ar7
    mov  r7, dpl
    inc  _XBUS_AUX
    mov  dptr, #_EP0_buffer
    dec  _XBUS_AUX
    mov  dpl, _USB_pDescr
    mov  dph, (_USB_pDescr + 1)
    01$:
    clr  a
    movc a, @a+dptr
    inc  dptr
    .db  0xA5
    djnz r7, 01$
    mov  _USB_pDescr, dpl
    mov  (_USB_pDescr + 1), dph
    pop  ar7
    pop  acc
  __endasm;
}

// ===================================================================================
// Endpoint EP0 Handlers
// ===================================================================================

void USB_EP0_SETUP(void) {
  uint8_t len = 0;
  USB_SetupLen = ((uint16_t)USB_SetupBuf->wLengthH<<8) | (USB_SetupBuf->wLengthL);
  USB_SetupReq = USB_SetupBuf->bRequest;
  USB_SetupTyp = USB_SetupBuf->bRequestType;

  if((USB_SetupTyp & USB_REQ_TYP_MASK) == USB_REQ_TYP_STANDARD) {
    switch(USB_SetupReq) {
      case USB_GET_DESCRIPTOR:
        switch(USB_SetupBuf->wValueH) {
          case USB_DESCR_TYP_DEVICE:
            USB_pDescr = (uint8_t*)&DevDescr;
            len = sizeof(DevDescr);
            break;
          case USB_DESCR_TYP_CONFIG:
            USB_pDescr = (uint8_t*)&CfgDescr;
            len = sizeof(CfgDescr);
            break;
          case USB_DESCR_TYP_STRING:
            switch(USB_SetupBuf->wValueL) {
              case 0:   USB_pDescr = USB_STR_DESCR_i0; break;
              case 1:   USB_pDescr = USB_STR_DESCR_i1; break;
              case 2:   USB_pDescr = USB_STR_DESCR_i2; break;
              case 3:   USB_pDescr = USB_STR_DESCR_i3; break;
              #ifdef USB_STR_DESCR_i4
              case 4:   USB_pDescr = USB_STR_DESCR_i4; break;
              #endif
              default:  USB_pDescr = USB_STR_DESCR_ix; break;
            }
            len = USB_pDescr[0];
            break;
          default:
            len = 0xff;
            break;
        }
        if(len != 0xff) {
          if(USB_SetupLen > len) USB_SetupLen = len;
          len = USB_SetupLen >= EP0_SIZE ? EP0_SIZE : USB_SetupLen;
          USB_EP0_copyDescr(len);
        }
        break;

      case USB_SET_ADDRESS:
        USB_Addr = USB_SetupBuf->wValueL;
        break;

      case USB_GET_CONFIGURATION:
        EP0_buffer[0] = USB_Config;
        if(USB_SetupLen > 1) USB_SetupLen = 1;
        len = USB_SetupLen;
        break;

      case USB_SET_CONFIGURATION:
        USB_Config  = USB_SetupBuf->wValueL;
        USB_ENUM_OK = 1;
        break;

      case USB_GET_INTERFACE:
        break;

      case USB_SET_INTERFACE:
        break;

      case USB_GET_STATUS:
        EP0_buffer[0] = 0x00;
        EP0_buffer[1] = 0x00;
        if(USB_SetupLen > 2) USB_SetupLen = 2;
        len = USB_SetupLen;
        break;

      case USB_CLEAR_FEATURE:
        if((USB_SetupTyp & USB_REQ_RECIP_MASK) == USB_REQ_RECIP_DEVICE) {
          if(USB_SetupBuf->wValueL == 0x01) {
            if(((uint8_t*)&CfgDescr)[7] & 0x20) {
              // wake up
            }
            else len = 0xff;
          }
          else len = 0xff;
        }
        else if((USB_SetupTyp & USB_REQ_RECIP_MASK) == USB_REQ_RECIP_ENDP) {
          switch(USB_SetupBuf->wIndexL) {
            #ifdef EP2_IN_callback
            case 0x82:
              UEP2_CTRL = (UEP2_CTRL & ~(bUEP_T_TOG | MASK_UEP_T_RES)) | UEP_T_RES_NAK;
              break;
            #endif
            default:
              len = 0xff;
              break;
          }
        }
        else len = 0xff;
        break;

      case USB_SET_FEATURE:
        if((USB_SetupTyp & USB_REQ_RECIP_MASK) == USB_REQ_RECIP_DEVICE) {
          if(USB_SetupBuf->wValueL == 0x01) {
            if( !(((uint8_t*)&CfgDescr)[7] & 0x20) ) len = 0xff;
          }
          else len = 0xff;
        }
        else if((USB_SetupTyp & USB_REQ_RECIP_MASK) == USB_REQ_RECIP_ENDP) {
          if(USB_SetupBuf->wValueL == 0x00) {
            switch(USB_SetupBuf->wIndexL) {
              #ifdef EP2_IN_callback
              case 0x82:
                UEP2_CTRL = (UEP2_CTRL & ~bUEP_T_TOG) | UEP_T_RES_STALL;
                break;
              #endif
              default:
                len = 0xff;
                break;
            }
          }
          else len = 0xff;
        }
        else len = 0xff;
        break;

      default:
        len = 0xff;
        break;
    }
  }

  #ifdef USB_CLASS_SETUP_handler
  else if((USB_SetupTyp & USB_REQ_TYP_MASK) == USB_REQ_TYP_CLASS) {
    len = USB_CLASS_SETUP_handler();
  }
  #endif

  #ifdef USB_VENDOR_SETUP_handler
  else if((USB_SetupTyp & USB_REQ_TYP_MASK) == USB_REQ_TYP_VENDOR) {
    len = USB_VENDOR_SETUP_handler();
  }
  #endif

  else len = 0xff;

  if(len == 0xff) {
    USB_SetupReq = 0xff;
    UEP0_CTRL  = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
  }
  else {
    USB_SetupLen -= len;
    UEP0_T_LEN    = len;
    UEP0_CTRL     = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
  }
}

void USB_EP0_IN(void) {
  uint8_t len;

  #ifdef USB_CLASS_IN_handler
  if((USB_SetupTyp & USB_REQ_TYP_MASK) == USB_REQ_TYP_CLASS) {
    USB_CLASS_IN_handler();
    return;
  }
  #endif

  #ifdef USB_VENDOR_IN_handler
  if((USB_SetupTyp & USB_REQ_TYP_MASK) == USB_REQ_TYP_VENDOR) {
    USB_VENDOR_IN_handler();
    return;
  }
  #endif

  switch(USB_SetupReq) {
    case USB_GET_DESCRIPTOR:
      len = USB_SetupLen >= EP0_SIZE ? EP0_SIZE : USB_SetupLen;
      USB_EP0_copyDescr(len);
      USB_SetupLen -= len;
      UEP0_T_LEN    = len;
      UEP0_CTRL    ^= bUEP_T_TOG;
      break;

    case USB_SET_ADDRESS:
      USB_DEV_AD = USB_DEV_AD & bUDA_GP_BIT | USB_Addr;
      UEP0_CTRL  = bUEP_R_TOG | UEP_T_RES_NAK | UEP_R_RES_ACK;
      break;

    default:
      UEP0_CTRL  = bUEP_R_TOG | UEP_T_RES_NAK | UEP_R_RES_ACK;
      break;
  }
}

void USB_EP0_OUT(void) {
  #ifdef USB_CLASS_OUT_handler
  if((USB_SetupTyp & USB_REQ_TYP_MASK) == USB_REQ_TYP_CLASS) {
    USB_CLASS_OUT_handler();
    return;
  }
  #endif

  #ifdef USB_VENDOR_OUT_handler
  if((USB_SetupTyp & USB_REQ_TYP_MASK) == USB_REQ_TYP_VENDOR) {
    USB_VENDOR_OUT_handler();
    return;
  }
  #endif

  UEP0_CTRL  = bUEP_T_TOG | UEP_T_RES_ACK | UEP_R_RES_ACK;
}

// ===================================================================================
// USB Interrupt Service Routine
// ===================================================================================
#pragma save
#pragma nooverlay
void USB_interrupt(void) __interrupt (INT_NO_USB) {
  if(UIF_TRANSFER) {
    uint8_t callIndex = USB_INT_ST & MASK_UIS_ENDP;
    switch (USB_INT_ST & MASK_UIS_TOKEN) {
      case UIS_TOKEN_SETUP:
        EP0_SETUP_callback();
        break;
      case UIS_TOKEN_IN:
        switch (callIndex) {
          case 0: EP0_IN_callback(); break;
          #ifdef EP2_IN_callback
          case 2: EP2_IN_callback(); break;
          #endif
          default: break;
        }
        break;
      case UIS_TOKEN_OUT:
        switch (callIndex) {
          case 0: EP0_OUT_callback(); break;
          #ifdef EP2_OUT_callback
          case 2: EP2_OUT_callback(); break;
          #endif
          default: break;
        }
        break;
    }
    UIF_TRANSFER = 0;
  }

  if(UIF_SUSPEND) {
    UIF_SUSPEND = 0;
    #ifdef USB_SUSPEND_handler
    if(USB_MIS_ST & bUMS_SUSPEND) {
      SAFE_MOD   = 0x55;
      SAFE_MOD   = 0xAA;
      WAKE_CTRL |= bWAK_BY_USB;
      USB_SUSPEND_handler();
      SAFE_MOD   = 0x55;
      SAFE_MOD   = 0xAA;
      WAKE_CTRL &= ~bWAK_BY_USB;
    }
    #endif
  }

  if(UIF_BUS_RST) {
    #ifdef USB_RESET_handler
    USB_RESET_handler();
    #endif
    USB_EP_init();
    USB_DEV_AD = 0x00;
    USB_INT_FG = 0x1f;
  }
}
#pragma restore