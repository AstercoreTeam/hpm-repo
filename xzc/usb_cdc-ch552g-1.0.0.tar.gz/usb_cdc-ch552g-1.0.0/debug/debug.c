#define _GNU_SOURCE
#define _DEFAULT_SOURCE
/*
 * CH552 USB CDC 虚拟化：在本机创建 PTY，把 CDC 端点映射成串口。
 *
 * 说明：这是用户态虚拟 USB CDC 串口，不是内核 USB gadget。
 * 固件通过 mcus 的 UsbEvent 完成枚举，host 侧用 PTY 暴露 /dev/pts/N。
 */
#include <hpm/debug/plugin.h>

#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <termios.h>
#include <unistd.h>

#define EP0 0
#define CDC_IN_EP 2
#define CDC_OUT_EP 2
#define CDC_NOTIFY_EP 1

#define USB_TOKEN_SETUP 0
#define USB_TOKEN_IN 1
#define USB_TOKEN_OUT 2
#define USB_TOKEN_EP_READY 6

#define USB_HS_NONE 0
#define USB_HS_ACK 1

typedef struct {
    const HpmDebugHostApi* api;
    char device[64];
    char slave[128];
    char link[512];

    int master;
    pthread_t usb_thread;
    pthread_t pty_thread;
    volatile int running;
    volatile int ep_ready;
    struct timespec last_out;
    volatile int out_pending;

    pthread_mutex_t mutex;
    pthread_mutex_t state_mutex;
    char tx[512];
    char out_line[512];
    size_t out_len;
    pthread_cond_t cond;
    int in_ready;
    uint32_t in_xfer;
    uint16_t in_len;
    uint8_t in_data[64];
    uint32_t next_xfer;
} CdcCtx;

static void emit_state(CdcCtx* ctx) {
    if (!ctx || !ctx->api) return;
    ctx->api->emit_json(ctx->api->host,
                        "{\"$state\":{\"send\":false}}");
}

static const char* find_key(const char* json, const char* key) {
    char pattern[96];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char* p = strstr(json, pattern);
    if (!p) return NULL;
    p += strlen(pattern);
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
    if (*p != ':') return NULL;
    ++p;
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
    return p;
}

static int get_string(const char* json, const char* key,
                      char* out, size_t cap) {
    const char* p = find_key(json, key);
    if (!p || *p != '"') return -1;
    ++p;
    size_t i = 0;
    while (*p && *p != '"') {
        char c = *p;
        if (c == '\\' && p[1]) {
            ++p;
            switch (*p) {
                case 'n': c = '\n'; break;
                case 'r': c = '\r'; break;
                case 't': c = '\t'; break;
                default: c = *p; break;
            }
        }
        if (i + 1 < cap) out[i++] = c;
        ++p;
    }
    out[i] = '\0';
    return 0;
}

static int get_bool(const char* json, const char* key, int def) {
    const char* p = find_key(json, key);
    if (!p) return def;
    if (strncmp(p, "true", 4) == 0) return 1;
    if (strncmp(p, "false", 5) == 0) return 0;
    if (strncmp(p, "1", 1) == 0) return 1;
    return def;
}

static void emit_ui(CdcCtx* ctx) {
    if (!ctx || !ctx->api) return;
    const char* ui =
        "{\"$ui\":{\"schema\":\"hpm-ui/1\","
        "\"role\":\"input\",\"title\":\"USB CDC\","
        "\"description\":\"CH552 USB CDC virtual serial\","
        "\"channels\":["
        "{\"id\":\"tx\",\"name\":\"发送内容\",\"direction\":\"in\","
        "\"type\":\"string\",\"widget\":\"textarea\",\"rows\":4,"
        "\"placeholder\":\"输入要发送到串口的内容\"},"
        "{\"id\":\"send\",\"name\":\"发送\",\"direction\":\"in\","
        "\"type\":\"bool\",\"widget\":\"button\",\"default\":false}],"
        "\"state\":{\"send\":false},\"order\":20}}";
    ctx->api->emit_json(ctx->api->host, ui);
}

static void append_output(CdcCtx* ctx, const uint8_t* data, size_t len) {
    if (!ctx || !data || !len) return;
    char line[1024];
    size_t n = len < sizeof(line) - 1 ? len : sizeof(line) - 1;
    for (size_t i = 0; i < n; ++i) {
        unsigned char c = data[i];
        line[i] = (c == '\r' || c == '\n') ? (char)c
                 : (c >= 0x20 && c < 0x7f) ? (char)c : '.';
    }
    line[n] = '\0';
    ctx->api->log(ctx->api->host, HPM_DEBUG_LOG_INFO, line);
}

static int send_serial(CdcCtx* ctx, const uint8_t* data, size_t len) {
    if (!ctx || !ctx->api || !ctx->api->usb_send || !data || !len) return -1;
    pthread_mutex_lock(&ctx->mutex);
    const uint32_t xfer = ctx->next_xfer++;
    pthread_mutex_unlock(&ctx->mutex);
    ctx->out_pending = 1;
    int rc = ctx->api->usb_send(ctx->api->host, xfer, CDC_OUT_EP,
                              USB_TOKEN_OUT, USB_HS_ACK, data,
                              (uint16_t)(len > 64 ? 64 : len));
    usleep(20000);
    ctx->out_pending = 0;
    return rc;
}

static void send_tx(CdcCtx* ctx) {
    char tx[512];
    pthread_mutex_lock(&ctx->state_mutex);
    snprintf(tx, sizeof(tx), "%s", ctx->tx);
    pthread_mutex_unlock(&ctx->state_mutex);

    if (tx[0]) {
        size_t l = strlen(tx);
        if (tx[l - 1] != '\n' && tx[l - 1] != '\r' &&
            l + 2 < sizeof(tx)) {
            tx[l++] = '\n';
            tx[l] = '\0';
        }
        char logbuf[560];
        snprintf(logbuf, sizeof(logbuf), "TX: %s", tx);
        ctx->api->log(ctx->api->host, HPM_DEBUG_LOG_INFO, logbuf);
    }

    size_t len = strlen(tx);
    while (len > 0) {
        size_t chunk = len > 64 ? 64 : len;
        if (send_serial(ctx, (const uint8_t*)tx, chunk) != 0) break;
        memmove(tx, tx + chunk, len - chunk);
        len -= chunk;
    }
    emit_state(ctx);
}

static void handle_json(CdcCtx* ctx, const char* text) {
    char cmd[32] = {0};
    if (get_string(text, "cmd", cmd, sizeof(cmd)) != 0) return;

    if (strcmp(cmd, "describe") == 0) {
        emit_ui(ctx);
        return;
    }
    if (strcmp(cmd, "get") == 0) {
        emit_state(ctx);
        return;
    }
    if (strcmp(cmd, "set") == 0) {
        char channel[64] = {0};
        get_string(text, "channel", channel, sizeof(channel));

        if (strcmp(channel, "tx") == 0 || channel[0] == 0) {
            char value[512] = {0};
            get_string(text, "value", value, sizeof(value));
            if (value[0] == 0) get_string(text, "tx", value, sizeof(value));
            pthread_mutex_lock(&ctx->state_mutex);
            snprintf(ctx->tx, sizeof(ctx->tx), "%s", value);
            pthread_mutex_unlock(&ctx->state_mutex);
            /* textarea 里按 Enter 时 GUI 会带 \n；这时直接发送，不需要再点按钮。 */
            if (strchr(value, '\n') || strchr(value, '\r')) {
                send_tx(ctx);
            }
        } else if (strcmp(channel, "send") == 0 && get_bool(text, "value", 0)) {
            send_tx(ctx);
        }
        return;
    }
    if (strcmp(cmd, "invoke") == 0) {
        char channel[64] = {0};
        get_string(text, "channel", channel, sizeof(channel));
        if (strcmp(channel, "send") == 0) send_tx(ctx);
    }
}

static int usb_in(CdcCtx* ctx, uint8_t ep, uint16_t want,
                  uint8_t* out, uint16_t* got) {
    if (!ctx->api || !ctx->api->usb_send) return -1;

    pthread_mutex_lock(&ctx->mutex);
    const uint32_t xfer = ctx->next_xfer++;
    ctx->in_ready = 0;
    ctx->in_len = 0;
    ctx->in_xfer = xfer;
    pthread_mutex_unlock(&ctx->mutex);

    if (ctx->api->usb_send(ctx->api->host, xfer, ep, USB_TOKEN_IN,
                           USB_HS_NONE, NULL, want) != 0) {
        return -1;
    }

    struct timespec deadline;
    clock_gettime(CLOCK_REALTIME, &deadline);
    deadline.tv_sec += 1;

    pthread_mutex_lock(&ctx->mutex);
    while (!ctx->in_ready && ctx->running) {
        if (pthread_cond_timedwait(&ctx->cond, &ctx->mutex, &deadline) ==
            ETIMEDOUT) {
            break;
        }
        if (ctx->in_xfer != xfer) break;
    }
    const int ok = ctx->in_ready && ctx->in_xfer == xfer;
    const uint16_t n = ok ? ctx->in_len : 0;
    const uint16_t cap = got ? *got : 0;
    uint16_t copied = 0;
    if (ok && out && n && cap) {
        copied = n < cap ? n : cap;
        memcpy(out, ctx->in_data, copied);
    }
    if (got) *got = copied;
    pthread_mutex_unlock(&ctx->mutex);
    return ok ? 0 : -1;
}

static int usb_setup(CdcCtx* ctx, uint8_t bmRequestType, uint8_t request,
                     uint16_t value, uint16_t index, uint16_t length) {
    if (!ctx->api || !ctx->api->usb_send) return -1;

    uint8_t setup[8];
    setup[0] = bmRequestType;
    setup[1] = request;
    setup[2] = (uint8_t)(value & 0xFF);
    setup[3] = (uint8_t)(value >> 8);
    setup[4] = (uint8_t)(index & 0xFF);
    setup[5] = (uint8_t)(index >> 8);
    setup[6] = (uint8_t)(length & 0xFF);
    setup[7] = (uint8_t)(length >> 8);

    pthread_mutex_lock(&ctx->mutex);
    const uint32_t xfer = ctx->next_xfer++;
    pthread_mutex_unlock(&ctx->mutex);

    return ctx->api->usb_send(ctx->api->host, xfer, EP0, USB_TOKEN_SETUP,
                              USB_HS_NONE, setup, sizeof(setup));
}

static int ctrl_in(CdcCtx* ctx, uint8_t bm, uint8_t req, uint16_t val,
                   uint16_t idx, uint16_t len, uint8_t* out, uint16_t* got) {
    if (usb_setup(ctx, bm, req, val, idx, len) != 0) return -1;
    usleep(30000);
    return usb_in(ctx, EP0, len, out, got);
}

static int ctrl_out_no_data(CdcCtx* ctx, uint8_t bm, uint8_t req,
                            uint16_t val, uint16_t idx) {
    if (usb_setup(ctx, bm, req, val, idx, 0) != 0) return -1;
    usleep(50000);
    return 0;
}

static int enumerate(CdcCtx* ctx) {
    uint8_t dev[64] = {0};
    uint16_t got = sizeof(dev);

    /* GET_DESCRIPTOR device */
    if (ctrl_in(ctx, 0x80, 0x06, 0x0100, 0, 18, dev, &got) != 0)
        return -1;
    if (got < 8) return -1;

    /* SET_ADDRESS */
    if (ctrl_out_no_data(ctx, 0x00, 0x05, 1, 0) != 0) return -1;
    usleep(30000);

    /* GET_DESCRIPTOR config */
    uint8_t cfg[64] = {0};
    got = sizeof(cfg);
    if (ctrl_in(ctx, 0x80, 0x06, 0x0200, 0, sizeof(cfg), cfg, &got) != 0)
        return -1;

    /* SET_CONFIGURATION */
    if (ctrl_out_no_data(ctx, 0x00, 0x09, 1, 0) != 0) return -1;
    usleep(30000);

    /* CDC SET_CONTROL_LINE_STATE: DTR | RTS */
    if (ctrl_out_no_data(ctx, 0x21, 0x22, 3, 0) != 0) return -1;
    usleep(50000);

    /* 最后再设置一次配置，避免被后续 setup 覆盖 */
    if (ctrl_out_no_data(ctx, 0x00, 0x09, 1, 0) != 0) return -1;
    usleep(100000);

    return 0;
}

static void* usb_thread_fn(void* arg) {
    CdcCtx* ctx = (CdcCtx*)arg;

    /* 等固件初始化端点，再开始枚举 */
    struct timespec deadline;
    clock_gettime(CLOCK_REALTIME, &deadline);
    deadline.tv_sec += 60;

    pthread_mutex_lock(&ctx->mutex);
    while (!ctx->ep_ready && ctx->running) {
        if (pthread_cond_timedwait(&ctx->cond, &ctx->mutex, &deadline) ==
            ETIMEDOUT) {
            break;
        }
    }
    pthread_mutex_unlock(&ctx->mutex);

    if (!ctx->running) return NULL;
    usleep(100000);

    if (enumerate(ctx) != 0) {
        ctx->api->log(ctx->api->host, HPM_DEBUG_LOG_ERROR,
                      "USB enumeration failed");
        return NULL;
    }
    ctx->api->log(ctx->api->host, HPM_DEBUG_LOG_INFO, "USB CDC enumerated");

    uint8_t data[64];
    int tick = 0;
    while (ctx->running) {
        if (ctx->out_pending) {
            usleep(1000);
            continue;
        }
        uint16_t got = sizeof(data);
        int irc = usb_in(ctx, CDC_IN_EP, sizeof(data), data, &got);
        if (irc == 0 && got > 0) {
            append_output(ctx, data, got);
            ssize_t w = write(ctx->master, data, got);
            (void)w;
        }

        /* EP1 通知端点也要排空，避免固件发送缓冲卡住 */
        if (++tick >= 5) {
            tick = 0;
            uint8_t note[8];
            uint16_t n = 0;
            (void)usb_in(ctx, CDC_NOTIFY_EP, sizeof(note), note, &n);
        }
        usleep(2000);
    }
    return NULL;
}

static void* pty_thread_fn(void* arg) {
    CdcCtx* ctx = (CdcCtx*)arg;
    uint8_t buf[64];

    while (ctx->running) {
        struct pollfd pfd;
        pfd.fd = ctx->master;
        pfd.events = POLLIN;
        int pr = poll(&pfd, 1, 100);
        if (pr <= 0) continue;

        ssize_t n = read(ctx->master, buf, sizeof(buf));
        if (n <= 0) continue;


        pthread_mutex_lock(&ctx->mutex);
        const uint32_t xfer = ctx->next_xfer++;
        pthread_mutex_unlock(&ctx->mutex);

        (void)ctx->api->usb_send(ctx->api->host, xfer, CDC_OUT_EP,
                                USB_TOKEN_OUT, USB_HS_ACK, buf,
                                (uint16_t)n);
        clock_gettime(CLOCK_MONOTONIC, &ctx->last_out);

    }
    return NULL;
}

static int setup_pty(CdcCtx* ctx) {
    ctx->master = posix_openpt(O_RDWR | O_NOCTTY);
    if (ctx->master < 0) return -1;
    if (grantpt(ctx->master) != 0 || unlockpt(ctx->master) != 0) return -1;

    const char* slave = ptsname(ctx->master);
    if (!slave) return -1;
    snprintf(ctx->slave, sizeof(ctx->slave), "%s", slave);

    int sfd = open(slave, O_RDWR | O_NOCTTY);
    if (sfd >= 0) {
        struct termios tio;
        if (tcgetattr(sfd, &tio) == 0) {
            cfmakeraw(&tio);
            tcsetattr(sfd, TCSANOW, &tio);
        }
        close(sfd);
    }

    const char* home = getenv("HOME");
    if (home && *home) {
        char dir[256];
        snprintf(dir, sizeof(dir), "%s/.hpm/usb-cdc", home);
        mkdir(home, 0755);
        mkdir(dir, 0755);

        snprintf(ctx->link, sizeof(ctx->link), "%s/%s.tty",
                 dir, ctx->device);
        unlink(ctx->link);
        if (symlink(slave, ctx->link) != 0) {
            ctx->link[0] = '\0';
        }
    }
    return 0;
}

uint32_t hpm_debug_abi_version(void) {
    return HPM_DEBUG_ABI_VERSION;
}

void* hpm_debug_create(const HpmDebugHostApi* api,
                       const HpmDebugDeviceInfo* info) {
    if (!api || !api->usb_send) return NULL;

    CdcCtx* ctx = (CdcCtx*)calloc(1, sizeof(CdcCtx));
    if (!ctx) return NULL;

    ctx->api = api;
    snprintf(ctx->device, sizeof(ctx->device), "%s",
             info && info->device ? info->device : "usb_cdc");
    ctx->master = -1;
    ctx->running = 1;
    ctx->next_xfer = 1;
    pthread_mutex_init(&ctx->mutex, NULL);
    pthread_mutex_init(&ctx->state_mutex, NULL);
    pthread_cond_init(&ctx->cond, NULL);

    if (setup_pty(ctx) != 0) {
        api->log(api->host, HPM_DEBUG_LOG_ERROR, "无法创建 PTY");
        free(ctx);
        return NULL;
    }

    char msg[768];
    snprintf(msg, sizeof(msg), "virtual USB CDC: %s", ctx->slave);
    api->log(api->host, HPM_DEBUG_LOG_INFO, msg);
    if (ctx->link[0]) {
        snprintf(msg, sizeof(msg), "serial symlink: %s", ctx->link);
        api->log(api->host, HPM_DEBUG_LOG_INFO, msg);
    }

    emit_ui(ctx);
    emit_state(ctx);

    pthread_create(&ctx->usb_thread, NULL, usb_thread_fn, ctx);
    pthread_create(&ctx->pty_thread, NULL, pty_thread_fn, ctx);
    return ctx;
}

void hpm_debug_destroy(void* handle) {
    CdcCtx* ctx = (CdcCtx*)handle;
    if (!ctx) return;

    ctx->running = 0;
    pthread_mutex_lock(&ctx->mutex);
    pthread_cond_broadcast(&ctx->cond);
    pthread_mutex_unlock(&ctx->mutex);

    pthread_join(ctx->usb_thread, NULL);
    pthread_join(ctx->pty_thread, NULL);

    if (ctx->link[0]) unlink(ctx->link);
    if (ctx->master >= 0) close(ctx->master);

    pthread_cond_destroy(&ctx->cond);
    pthread_mutex_destroy(&ctx->state_mutex);
    pthread_mutex_destroy(&ctx->mutex);
    free(ctx);
}

int hpm_debug_event(void* handle, const HpmDebugEvent* ev) {
    CdcCtx* ctx = (CdcCtx*)handle;
    if (!ctx || !ev) return -1;

    if (ev->type == HPM_DEBUG_EVENT_JSON) {
        if (ev->u.json) handle_json(ctx, ev->u.json);
        return 0;
    }

    if (ev->type == HPM_DEBUG_EVENT_USB) {
        const HpmDebugUsbEvent* u = &ev->u.usb;
        if (u->token == USB_TOKEN_EP_READY) {
            pthread_mutex_lock(&ctx->mutex);
            ctx->ep_ready = 1;
            pthread_cond_broadcast(&ctx->cond);
            pthread_mutex_unlock(&ctx->mutex);
        } else if (u->token == USB_TOKEN_IN) {
            pthread_mutex_lock(&ctx->mutex);
            if (u->xfer_id == ctx->in_xfer) {
                ctx->in_ready = 1;
                ctx->in_len = u->len > sizeof(ctx->in_data)
                                  ? sizeof(ctx->in_data)
                                  : u->len;
                if (u->data && ctx->in_len) {
                    memcpy(ctx->in_data, u->data, ctx->in_len);
                }
                pthread_cond_broadcast(&ctx->cond);
            }
            pthread_mutex_unlock(&ctx->mutex);
        }
    }
    return 0;
}
