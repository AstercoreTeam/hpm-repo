#pragma once
#include <stdint.h>
#include "CH552.H"
#include "hpm_dev.h"

// 默认值
#ifndef usb_vid
#define usb_vid            0x1209
#endif
#ifndef usb_pid
#define usb_pid            0x0001
#endif
#ifndef usb_device_version
#define usb_device_version 0x0100
#endif
#ifndef usb_max_power_ma
#define usb_max_power_ma   100
#endif

// ── USB 结构体 ──
#ifndef __USB_SETUP_REQ_DEFINED
#define __USB_SETUP_REQ_DEFINED
typedef struct _USB_SETUP_REQ {
    uint8_t bRequestType;
    uint8_t bRequest;
    uint8_t wValueL;
    uint8_t wValueH;
    uint8_t wIndexL;
    uint8_t wIndexH;
    uint8_t wLengthL;
    uint8_t wLengthH;
} USB_SETUP_REQ, *PUSB_SETUP_REQ;
#endif

#ifndef __USB_DEV_DESCR_DEFINED
#define __USB_DEV_DESCR_DEFINED
typedef struct _USB_DEV_DESCR {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bcdUSBL;
    uint8_t bcdUSBH;
    uint8_t bDeviceClass;
    uint8_t bDeviceSubClass;
    uint8_t bDeviceProtocol;
    uint8_t bMaxPacketSize0;
    uint8_t idVendorL;
    uint8_t idVendorH;
    uint8_t idProductL;
    uint8_t idProductH;
    uint8_t bcdDeviceL;
    uint8_t bcdDeviceH;
    uint8_t iManufacturer;
    uint8_t iProduct;
    uint8_t iSerialNumber;
    uint8_t bNumConfigurations;
} USB_DEV_DESCR, *PUSB_DEV_DESCR;
#endif

#ifndef __USB_CFG_DESCR_DEFINED
#define __USB_CFG_DESCR_DEFINED
typedef struct _USB_CFG_DESCR {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t wTotalLengthL;
    uint8_t wTotalLengthH;
    uint8_t bNumInterfaces;
    uint8_t bConfigurationValue;
    uint8_t iConfiguration;
    uint8_t bmAttributes;
    uint8_t MaxPower;
} USB_CFG_DESCR, *PUSB_CFG_DESCR;
#endif

#ifndef __USB_ITF_DESCR_DEFINED
#define __USB_ITF_DESCR_DEFINED
typedef struct _USB_ITF_DESCR {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bInterfaceNumber;
    uint8_t bAlternateSetting;
    uint8_t bNumEndpoints;
    uint8_t bInterfaceClass;
    uint8_t bInterfaceSubClass;
    uint8_t bInterfaceProtocol;
    uint8_t iInterface;
} USB_ITF_DESCR, *PUSB_ITF_DESCR;
#endif

#ifndef __USB_ENDP_DESCR_DEFINED
#define __USB_ENDP_DESCR_DEFINED
typedef struct _USB_ENDP_DESCR {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bEndpointAddress;
    uint8_t bmAttributes;
    uint8_t wMaxPacketSizeL;
    uint8_t wMaxPacketSizeH;
    uint8_t bInterval;
} USB_ENDP_DESCR, *PUSB_ENDP_DESCR;
#endif

#ifndef __USB_IAD_DESCR_DEFINED
#define __USB_IAD_DESCR_DEFINED
typedef struct _USB_IAD_DESCR {
    uint8_t bLength;
    uint8_t bDescriptorType;
    uint8_t bFirstInterface;
    uint8_t bInterfaceCount;
    uint8_t bFunctionClass;
    uint8_t bFunctionSubClass;
    uint8_t bFunctionProtocol;
    uint8_t iFunction;
} USB_IAD_DESCR, *PUSB_IAD_DESCR;
#endif

// ── 常量 ──
#ifndef USB_DESCR_TYP_DEVICE
#define USB_DESCR_TYP_DEVICE    0x01
#endif
#ifndef USB_DESCR_TYP_CONFIG
#define USB_DESCR_TYP_CONFIG    0x02
#endif
#ifndef USB_DESCR_TYP_STRING
#define USB_DESCR_TYP_STRING    0x03
#endif
#ifndef USB_DESCR_TYP_INTERF
#define USB_DESCR_TYP_INTERF    0x04
#endif
#ifndef USB_DESCR_TYP_ENDP
#define USB_DESCR_TYP_ENDP      0x05
#endif
#ifndef USB_DESCR_TYP_IAD
#define USB_DESCR_TYP_IAD       0x0B
#endif

#ifndef USB_DEV_CLASS_COMM
#define USB_DEV_CLASS_COMM      0x02
#endif
#ifndef USB_DEV_CLASS_DATA
#define USB_DEV_CLASS_DATA      0x0A
#endif

#ifndef USB_ENDP_TYPE_CTRL
#define USB_ENDP_TYPE_CTRL      0x00
#endif
#ifndef USB_ENDP_TYPE_ISOCH
#define USB_ENDP_TYPE_ISOCH     0x01
#endif
#ifndef USB_ENDP_TYPE_BULK
#define USB_ENDP_TYPE_BULK      0x02
#endif
#ifndef USB_ENDP_TYPE_INTER
#define USB_ENDP_TYPE_INTER     0x03
#endif

#ifndef USB_ENDP_ADDR_EP1_IN
#define USB_ENDP_ADDR_EP1_IN    0x81
#endif
#ifndef USB_ENDP_ADDR_EP2_OUT
#define USB_ENDP_ADDR_EP2_OUT   0x02
#endif
#ifndef USB_ENDP_ADDR_EP2_IN
#define USB_ENDP_ADDR_EP2_IN    0x82
#endif

// ── USB 请求 ──
#ifndef USB_GET_STATUS
#define USB_GET_STATUS          0x00
#endif
#ifndef USB_CLEAR_FEATURE
#define USB_CLEAR_FEATURE       0x01
#endif
#ifndef USB_SET_FEATURE
#define USB_SET_FEATURE         0x03
#endif
#ifndef USB_SET_ADDRESS
#define USB_SET_ADDRESS         0x05
#endif
#ifndef USB_GET_DESCRIPTOR
#define USB_GET_DESCRIPTOR      0x06
#endif
#ifndef USB_SET_DESCRIPTOR
#define USB_SET_DESCRIPTOR      0x07
#endif
#ifndef USB_GET_CONFIGURATION
#define USB_GET_CONFIGURATION   0x08
#endif
#ifndef USB_SET_CONFIGURATION
#define USB_SET_CONFIGURATION   0x09
#endif
#ifndef USB_GET_INTERFACE
#define USB_GET_INTERFACE       0x0A
#endif
#ifndef USB_SET_INTERFACE
#define USB_SET_INTERFACE       0x0B
#endif
#ifndef USB_SYNCH_FRAME
#define USB_SYNCH_FRAME         0x0C
#endif

#ifndef USB_REQ_TYP_MASK
#define USB_REQ_TYP_IN          0x80
#define USB_REQ_TYP_OUT         0x00
#define USB_REQ_TYP_MASK        0x60
#define USB_REQ_TYP_STANDARD    0x00
#define USB_REQ_TYP_CLASS       0x20
#define USB_REQ_TYP_VENDOR      0x40
#define USB_REQ_TYP_RESERVED    0x60
#define USB_REQ_RECIP_MASK      0x1F
#define USB_REQ_RECIP_DEVICE    0x00
#define USB_REQ_RECIP_INTERF    0x01
#define USB_REQ_RECIP_ENDP      0x02
#define USB_REQ_RECIP_OTHER     0x03
#endif

// ── USB 寄存器位 ──
#ifndef bUD_DP_PD_DIS
#define bUD_DP_PD_DIS   0x80
#endif
#ifndef bUD_DM_PD_DIS
#define bUD_DM_PD_DIS   0x10
#endif
#ifndef bUD_PORT_EN
#define bUD_PORT_EN     0x01
#endif
#ifndef bUC_DEV_PU_EN
#define bUC_DEV_PU_EN   0x20
#endif
#ifndef bUC_INT_BUSY
#define bUC_INT_BUSY    0x08
#endif
#ifndef bUC_DMA_EN
#define bUC_DMA_EN      0x01
#endif
#ifndef bUIE_SUSPEND
#define bUIE_SUSPEND    0x04
#endif
#ifndef bUIE_TRANSFER
#define bUIE_TRANSFER   0x02
#endif
#ifndef bUIE_BUS_RST
#define bUIE_BUS_RST    0x01
#endif
#ifndef bUEP_AUTO_TOG
#define bUEP_AUTO_TOG   0x10
#endif
#ifndef bUEP_R_TOG
#define bUEP_R_TOG      0x80
#endif
#ifndef bUEP_T_TOG
#define bUEP_T_TOG      0x40
#endif
#ifndef MASK_UEP_R_RES
#define MASK_UEP_R_RES  0x0C
#endif
#ifndef UEP_R_RES_ACK
#define UEP_R_RES_ACK   0x00
#endif
#ifndef UEP_R_RES_NAK
#define UEP_R_RES_NAK   0x08
#endif
#ifndef UEP_R_RES_STALL
#define UEP_R_RES_STALL 0x0C
#endif
#ifndef MASK_UEP_T_RES
#define MASK_UEP_T_RES  0x03
#endif
#ifndef UEP_T_RES_ACK
#define UEP_T_RES_ACK   0x00
#endif
#ifndef UEP_T_RES_NAK
#define UEP_T_RES_NAK   0x02
#endif
#ifndef UEP_T_RES_STALL
#define UEP_T_RES_STALL 0x03
#endif
#ifndef bUEP2_RX_EN
#define bUEP2_RX_EN     0x08
#endif
#ifndef bUEP2_TX_EN
#define bUEP2_TX_EN     0x04
#endif
#ifndef bUEP1_TX_EN
#define bUEP1_TX_EN     0x40
#endif
#ifndef MASK_UIS_ENDP
#define MASK_UIS_ENDP   0x0F
#endif
#ifndef MASK_UIS_TOKEN
#define MASK_UIS_TOKEN  0x30
#endif
#ifndef UIS_TOKEN_SETUP
#define UIS_TOKEN_SETUP 0x30
#endif
#ifndef UIS_TOKEN_IN
#define UIS_TOKEN_IN    0x20
#endif
#ifndef UIS_TOKEN_OUT
#define UIS_TOKEN_OUT   0x00
#endif
#ifndef bUDA_GP_BIT
#define bUDA_GP_BIT     0x80
#endif
#ifndef bWAK_BY_USB
#define bWAK_BY_USB     0x80
#endif

// ── EP buffer ──
#define EP0_SIZE        8
#define EP1_SIZE        8
#define EP2_SIZE        64

#define EP0_BUF_SIZE    (EP0_SIZE + 2)
#define EP1_BUF_SIZE    (EP1_SIZE + 2)
#define EP2_BUF_SIZE    (EP2_SIZE + 64 + 2)

#define EP0_ADDR        0
#define EP1_ADDR        (EP0_ADDR + EP0_BUF_SIZE)
#define EP2_ADDR        (EP1_ADDR + EP1_BUF_SIZE)

extern __xdata __at (EP0_ADDR) uint8_t EP0_buffer[EP0_BUF_SIZE];
extern __xdata __at (EP1_ADDR) uint8_t EP1_buffer[EP1_BUF_SIZE];
extern __xdata __at (EP2_ADDR) uint8_t EP2_buffer[EP2_BUF_SIZE];

// ── CDC 配置描述符 ──
typedef struct _USB_CFG_DESCR_CDC {
    USB_CFG_DESCR config;
    USB_IAD_DESCR association;
    USB_ITF_DESCR interface0;
    uint8_t functional[19];
    USB_ENDP_DESCR ep1IN;
    USB_ITF_DESCR interface1;
    USB_ENDP_DESCR ep2OUT;
    USB_ENDP_DESCR ep2IN;
} USB_CFG_DESCR_CDC;

// ── 外部声明 ──
extern __code USB_DEV_DESCR DevDescr;
extern __code USB_CFG_DESCR_CDC CfgDescr;

extern __code uint16_t LangDescr[];
extern __code uint16_t ManufDescr[];
extern __code uint16_t ProdDescr[];
extern __code uint16_t SerDescr[];
extern __code uint16_t InterfDescr[];

#define USB_STR_DESCR_i0    (uint8_t*)LangDescr
#define USB_STR_DESCR_i1    (uint8_t*)ManufDescr
#define USB_STR_DESCR_i2    (uint8_t*)ProdDescr
#define USB_STR_DESCR_i3    (uint8_t*)SerDescr
#define USB_STR_DESCR_i4    (uint8_t*)InterfDescr
#define USB_STR_DESCR_ix    (uint8_t*)SerDescr
