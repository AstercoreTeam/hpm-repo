#include "stepper.h"

#define HPM_CAT_(a, b) a##b
#define HPM_CAT(a, b)  HPM_CAT_(a, b)
#define HPM_FN(name)   HPM_CAT(DEVICE_NAME, HPM_CAT(_, name))
#define HPM_CALL(prefix, method) HPM_CAT(prefix, HPM_CAT(_, method))

static void step_delay(void) {
    for (volatile unsigned int i = 0; i < 20; ++i) {
    }
}

int HPM_FN(init)(void) {
    HPM_CALL(step, init)();
    HPM_CALL(dir, init)();
    HPM_CALL(step, write)(0);
    HPM_CALL(dir, write)(0);
    return 0;
}

void HPM_FN(set_dir)(int direction) {
    HPM_CALL(dir, write)(direction ? 1 : 0);
}

void HPM_FN(pulse)(unsigned int steps) {
    while (steps--) {
        HPM_CALL(step, write)(1);
        step_delay();
        HPM_CALL(step, write)(0);
        step_delay();
    }
}
