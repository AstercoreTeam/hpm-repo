#include "hpm_pin.h"
#include "ch552g.h"

// 推挽输出：Pn_MOD_OC[x]=0, Pn_DIR_PU[x]=1
#define DEF_PIN(port, bit) \
    void hpm_pin_##port##_##bit##_init(void) { \
        port##_MOD_OC &= ~(1 << bit); \
        port##_DIR_PU |=  (1 << bit); \
    } \
    void hpm_pin_##port##_##bit##_write(int level) { \
        if (level) port |=  (1 << bit); \
        else       port &= ~(1 << bit); \
    } \
    int hpm_pin_##port##_##bit##_read(void) { \
        return (port >> bit) & 1; \
    }

DEF_PIN(P1, 1)
DEF_PIN(P1, 4)
DEF_PIN(P1, 5)
DEF_PIN(P3, 0)
DEF_PIN(P3, 1)
DEF_PIN(P3, 2)
DEF_PIN(P3, 3)
DEF_PIN(P3, 4)