#include "ch552g.h"

void ch552g_init(void) {
    ch552g_clock_24m();
}