#include "hpm_pin.h"
#include "stm32f103c8t6.h"

#define DEF_PIN(name, port, pin) \
void hpm_pin_##name##_init(void) { \
    RCC->APB2ENR |= RCC_APB2ENR_IOP##port##EN; \
    volatile uint32_t* cr = (pin < 8) ? &GPIO##port->CRL : &GPIO##port->CRH; \
    uint32_t shift = (pin % 8) * 4; \
    *cr &= ~(0xF << shift); \
    *cr |= (0x2 << shift); /* 输出 2MHz 推挽 */ \
} \
void hpm_pin_##name##_write(int level) { \
    if (level) GPIO##port->BSRR = (1 << pin); \
        else       GPIO##port->BSRR = (1 << (pin + 16)); \
} \
int hpm_pin_##name##_read(void) { \
    return (GPIO##port->IDR >> pin) & 1; \
}

DEF_PIN(PA4, A, 4)
DEF_PIN(PA5, A, 5)
DEF_PIN(PA6, A, 6)
DEF_PIN(PA7, A, 7)
DEF_PIN(PB0, B, 0)
