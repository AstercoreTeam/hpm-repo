#include "stm32f103c8t6.h"

void clock_72m(void) {
    RCC->CR |= RCC_CR_HSEON;
    
    // 等待晶振起振（加入了超时退出）
    uint32_t timeout = 0xFFFFFF;
    while (!(RCC->CR & RCC_CR_HSERDY) && timeout--);
    
    // 如果超时了，说明外部晶振没起振
    if (timeout == 0) {
        // 让 PC13 快速闪烁报警
        RCC->APB2ENR |= (1 << 4);
        GPIOC->CRH &= ~(0x0F << 20);
        GPIOC->CRH |= (0x02 << 20);
        while(1) {
            GPIOC->BSRR = (1 << 13); for(int i=0; i<100000; i++);
            GPIOC->BSRR = (1 << (13+16)); for(int i=0; i<100000; i++);
        }
    }

    RCC->CFGR |= RCC_CFGR_PLLSRC | RCC_CFGR_PLLMULL9;
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));
    FLASH->ACR = FLASH_ACR_PRFTBE | FLASH_ACR_LATENCY_2;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);
}

void stm32f103c8t6_init(void) {
    clock_72m();
}
