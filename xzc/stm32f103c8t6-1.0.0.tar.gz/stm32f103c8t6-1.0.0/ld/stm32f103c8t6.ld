ENTRY(Reset_Handler)

MEMORY {
    FLASH (rx)  : ORIGIN = 0x08000000, LENGTH = 64K
    RAM   (rwx) : ORIGIN = 0x20000000, LENGTH = 20K
}

SECTIONS {
    .isr_vector : {
        KEEP(*(.isr_vector))
    } > FLASH

    .text : {
        KEEP(*(.text*))
        KEEP(*(.rodata*))
    } > FLASH

    _sidata = LOADADDR(.data);

    .data : {
        _sdata = .;
        *(.data*)
        _edata = .;
    } > RAM AT > FLASH

    .bss : { 
        . = ALIGN(4);
        _sbss = .; 
        __bss_start__ = .;
        *(.bss*) 
        *(COMMON) 
        . = ALIGN(4);
        _ebss = .; 
        __bss_end__ = .;
    } > RAM

    _estack = ORIGIN(RAM) + LENGTH(RAM);
    end = .;
}
