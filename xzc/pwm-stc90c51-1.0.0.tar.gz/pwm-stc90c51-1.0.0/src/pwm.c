#include "pwm.h"
#include "config.h"
#include "stc90c51_reg.h"

#define HPM_CAT_(a, b) a##b
#define HPM_CAT(a, b)  HPM_CAT_(a, b)
#define HPM_FN(name)   HPM_CAT(DEVICE_NAME, HPM_CAT(_, name))

volatile unsigned char pwm_pulse = 33;  /* 改为 8 位，速度快 */
volatile unsigned char pwm_running = 0;
volatile unsigned char pwm_in_high = 0;

void pwm_timer0_isr(void) __interrupt(1) {
    TCON &= ~0x10; /* 暂停定时器 */

    if (pwm_running) {
        if (pwm_in_high) {
            P1_0 = 0;
            pwm_in_high = 0;

            /* 计算低电平时间： (200 - pulse) * 46 */
            {
                unsigned int reload = ((unsigned int)(200 - pwm_pulse)) * 46;
                TH0 = (65536 - reload) >> 8;
                TL0 = (65536 - reload) & 0xFF;
            }
        } else {
            P1_0 = 1;
            pwm_in_high = 1;

            /* 计算高电平时间： pulse * 46 */
            {
                unsigned int reload = ((unsigned int)pwm_pulse) * 46;
                TH0 = (65536 - reload) >> 8;
                TL0 = (65536 - reload) & 0xFF;
            }
        }
    } else {
        P1_0 = 0;
    }

    TCON |= 0x10; /* 恢复定时器 */
}

int HPM_FN(init)(void) {
    P1_0 = 0;
    pwm_pulse = 33;
    pwm_running = 0;
    pwm_in_high = 0;

    TMOD = (TMOD & 0xF0) | 0x01;
    TH0 = 0xFF;
    TL0 = 0xD2;
    IE |= 0x82;
    TCON &= ~0x10;

    return 0;
}

int HPM_FN(start)(void) {
    pwm_running = 1;
    pwm_in_high = 1;
    P1_0 = 1;

    {
        unsigned int reload = ((unsigned int)pwm_pulse) * 46;
        TH0 = (65536 - reload) >> 8;
        TL0 = (65536 - reload) & 0xFF;
    }

    TCON |= 0x10;
    return 0;
}

int HPM_FN(set_duty)(unsigned int permille) {
    if (permille > 1000u) return -1;
    pwm_pulse = (unsigned char)((permille * 200) / 1000);
    return 0;
}
