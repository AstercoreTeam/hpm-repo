/*
 * pwm-stc90c51 舵机虚拟化插件。
 *
 * 设备：舵机（输出设备）。
 * 通道：angle（0-180°）、duty_pct（0-100）。
 *
 * 原理：监听 project.json 绑定的 PWM 引脚，用相邻上升沿得到周期、
 * 上升沿到下降沿得到高电平时间，高电平占空比映射到 0-180°。
 * 标准 50Hz 舵机：1ms=0°、1.5ms=90°、2ms=180°（占空比 5%-10%）。
 */
#include <hpm/debug/plugin.h>

#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    const HpmDebugHostApi* api;
    char name[64];
    char pin[64];
    int has_pin;

    uint32_t level;
    uint64_t last_rise;
    uint64_t high_start;
    double period;
    double min_duty;
    double max_duty;

    double angle;
    double duty_pct;
    int has_state;
} ServoCtx;

static const char* find_key(const char* json, const char* key) {
    char pattern[96];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);

    const char* p = strstr(json, pattern);
    if (!p) return NULL;
    p += strlen(pattern);
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
    if (*p != ':') return NULL;
    ++p;
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
    return p;
}

static int get_string(const char* json, const char* key, char* out, size_t cap) {
    const char* p = find_key(json, key);
    if (!p || *p != '"') return -1;
    ++p;

    size_t i = 0;
    while (*p && *p != '"') {
        if (*p == '\\' && p[1]) ++p;
        if (i + 1 < cap) out[i++] = *p;
        ++p;
    }
    out[i] = '\0';
    return 0;
}

static void emit_ui(ServoCtx* ctx) {
    char json[768];
    snprintf(json, sizeof(json),
             "{\"$ui\":{\"schema\":\"hpm-ui/1\","
             "\"role\":\"output\",\"title\":\"Servo\","
             "\"description\":\"PWM servo\","
             "\"channels\":["
             "{\"id\":\"angle\",\"name\":\"Angle\",\"direction\":\"out\","
             "\"type\":\"number\",\"widget\":\"slider\",\"min\":0,\"max\":180,"
             "\"unit\":\"deg\",\"readonly\":true},"
             "{\"id\":\"duty_pct\",\"name\":\"Duty\",\"direction\":\"out\","
             "\"type\":\"number\",\"widget\":\"text\",\"min\":0,\"max\":100,"
             "\"unit\":\"pct\",\"readonly\":true}],"
             "\"state\":{\"angle\":%.1f,\"duty_pct\":%.2f},"
             "\"pins\":[\"%s\"],\"order\":20}}",
             ctx->angle, ctx->duty_pct, ctx->pin);
    ctx->api->emit_json(ctx->api->host, json);
}

static void emit_state(ServoCtx* ctx) {
    char json[160];
    snprintf(json, sizeof(json),
             "{\"$state\":{\"angle\":%.1f,\"duty_pct\":%.2f}}",
             ctx->angle, ctx->duty_pct);
    ctx->api->emit_json(ctx->api->host, json);
}

static void emit_error(ServoCtx* ctx, const char* code, const char* message,
                       const char* channel, int fatal) {
    char json[256];
    snprintf(json, sizeof(json),
             "{\"$error\":{\"code\":\"%s\",\"message\":\"%s\","
             "\"channel\":\"%s\",\"fatal\":%s}}",
             code, message, channel, fatal ? "true" : "false");
    ctx->api->emit_json(ctx->api->host, json);
}

static void set_duty(ServoCtx* ctx, double duty) {
    if (duty <= ctx->min_duty - 0.02 || duty >= ctx->max_duty + 0.02) {
        return; /* 明显不是舵机信号：忽略，避免乱跳 */
    }
    double ratio = (duty - ctx->min_duty) / (ctx->max_duty - ctx->min_duty);
    if (ratio < 0.0) ratio = 0.0;
    if (ratio > 1.0) ratio = 1.0;
    const double angle = ratio * 180.0;
    const double duty_pct = duty * 100.0;

    if (ctx->has_state && fabs(angle - ctx->angle) < 0.5 &&
        fabs(duty_pct - ctx->duty_pct) < 0.2) {
        return;
    }
    ctx->angle = angle;
    ctx->duty_pct = duty_pct;
    ctx->has_state = 1;
    emit_state(ctx);
}

static void on_pin(ServoCtx* ctx, const HpmDebugPinEvent* pin) {
    if (!ctx->has_pin || !pin->pin || strcmp(pin->pin, ctx->pin) != 0) return;

    const uint32_t value = pin->value ? 1u : 0u;
    const uint64_t now = pin->time;
    if (value == ctx->level) return;

    if (value) {
        if (ctx->last_rise > 0 && now > ctx->last_rise) {
            ctx->period = (double)(now - ctx->last_rise);
        }
        ctx->last_rise = now;
        ctx->high_start = now;
        ctx->level = 1;
    } else {
        if (ctx->high_start > 0 && now > ctx->high_start && ctx->period > 0.0) {
            const double high = (double)(now - ctx->high_start);
            set_duty(ctx, high / ctx->period);
        }
        ctx->high_start = 0;
        ctx->level = 0;
    }
}

static void handle_json(ServoCtx* ctx, const char* text) {
    char cmd[32] = {0};
    if (get_string(text, "cmd", cmd, sizeof(cmd)) != 0) return;

    if (strcmp(cmd, "describe") == 0) {
        emit_ui(ctx);
        return;
    }
    if (strcmp(cmd, "get") == 0) {
        emit_state(ctx);
        return;
    }
    if (strcmp(cmd, "set") == 0) {
        char channel[64] = {0};
        get_string(text, "channel", channel, sizeof(channel));
        if (strcmp(channel, "angle") == 0 || strcmp(channel, "duty_pct") == 0) {
            emit_error(ctx, "readonly", "servo is output-only", channel, 0);
        } else {
            emit_error(ctx, "unknown_channel", "unknown channel", channel, 0);
        }
        return;
    }
    if (strcmp(cmd, "invoke") == 0) {
        char channel[64] = {0};
        get_string(text, "channel", channel, sizeof(channel));
        emit_error(ctx, "unsupported", "servo has no actions", channel, 0);
    }
}

uint32_t hpm_debug_abi_version(void) {
    return HPM_DEBUG_ABI_VERSION;
}

void* hpm_debug_create(const HpmDebugHostApi* api,
                       const HpmDebugDeviceInfo* info) {
    if (!api || !info) return NULL;

    ServoCtx* ctx = (ServoCtx*)calloc(1, sizeof(ServoCtx));
    if (!ctx) return NULL;

    ctx->api = api;
    snprintf(ctx->name, sizeof(ctx->name), "%s",
             info->device ? info->device : "servo");
    ctx->pin[0] = '\0';
    ctx->min_duty = 0.05;
    ctx->max_duty = 0.10;
    ctx->angle = 90.0;
    ctx->duty_pct = 7.5;

    for (size_t i = 0; i < info->config_count; ++i) {
        const char* key = info->config[i].key;
        const char* value = info->config[i].value;
        if (!key || !value) continue;
        if (strcmp(key, "min_duty") == 0) ctx->min_duty = atof(value);
        if (strcmp(key, "max_duty") == 0) ctx->max_duty = atof(value);
    }
    if (ctx->min_duty > 1.0) ctx->min_duty /= 100.0;
    if (ctx->max_duty > 1.0) ctx->max_duty /= 100.0;
    if (ctx->max_duty <= ctx->min_duty) {
        ctx->min_duty = 0.05;
        ctx->max_duty = 0.10;
    }

    for (size_t i = 0; i < info->binding_count; ++i) {
        const char* key = info->bindings[i].key;
        const char* value = info->bindings[i].value;
        if (!key || !value) continue;
        if (strcmp(key, "pin") == 0 || strcmp(key, "pwm") == 0 ||
            strcmp(key, "out") == 0 || strcmp(key, "signal") == 0) {
            snprintf(ctx->pin, sizeof(ctx->pin), "%s", value);
            ctx->has_pin = 1;
            break;
        }
    }

    if (ctx->has_pin) {
        uint32_t value = 0, function = 0, direction = 0;
        if (api->get_pin(api->host, ctx->pin, &value, &function,
                         &direction) == 0) {
            ctx->level = value ? 1u : 0u;
        }
    } else {
        api->log(api->host, HPM_DEBUG_LOG_WARN,
                 "servo has no pin binding; angle stays at 90");
    }

    emit_ui(ctx);
    emit_state(ctx);
    return ctx;
}

void hpm_debug_destroy(void* handle) {
    free(handle);
}

int hpm_debug_event(void* handle, const HpmDebugEvent* ev) {
    ServoCtx* ctx = (ServoCtx*)handle;
    if (!ctx || !ev) return -1;

    switch (ev->type) {
        case HPM_DEBUG_EVENT_PIN:
            on_pin(ctx, &ev->u.pin);
            break;
        case HPM_DEBUG_EVENT_JSON:
            if (ev->u.json) handle_json(ctx, ev->u.json);
            break;
        default:
            break;
    }
    return 0;
}
