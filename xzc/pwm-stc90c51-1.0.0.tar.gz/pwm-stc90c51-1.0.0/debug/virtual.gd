# 舵机（pwm 驱动）虚拟设备脚本。
#
# 输出通道 angle(0-180) 或 duty_pct(0-100) -> 舵机摆臂角度。
# 0° 对应摆臂 -90°，90° 居中，180° 对应 +90°。
extends "res://sdk/virtual_device.gd"

var _horn: Node3D
var _current := 90.0
var _target := 90.0
var _speed := 240.0

func _on_bind(ctx: Dictionary) -> void:
	var props: Dictionary = ctx.get("props", {})
	_speed = maxf(float(props.get("speed_deg_per_s", 240.0)), 10.0)
	_horn = get_model_node("ServoHorn") as Node3D
	if _horn == null:
		_horn = get_model_node("Horn") as Node3D
	if _horn == null:
		log_warn("模型缺少 ServoHorn 节点，舵机不会转动")
		return
	_apply(90.0)
	log_info("舵机已绑定")

func _on_values(values: Dictionary) -> void:
	var angle: Variant = values.get("angle")
	if angle == null:
		var duty_pct: Variant = values.get("duty_pct")
		if duty_pct == null:
			var duty: Variant = values.get("duty")
			if duty != null:
				angle = (float(duty) - 0.05) / 0.05 * 180.0
		else:
			angle = (float(duty_pct) - 5.0) / 5.0 * 180.0
	if angle == null:
		return
	_target = clampf(float(angle), 0.0, 180.0)

func _on_session_stop() -> void:
	_target = _current

func _on_tick(delta: float) -> void:
	if _horn == null or is_equal_approx(_current, _target):
		return
	_current = move_toward(_current, _target, _speed * delta)
	_apply(_current)

func _apply(angle: float) -> void:
	if _horn != null:
		_horn.rotation_degrees.y = angle - 90.0
