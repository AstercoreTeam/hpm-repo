#pragma once
#ifndef HPM_DEV_MACROS
#define HPM_DEV_MACROS
#include "hpm_dev.h"
#endif
#include <stdint.h>

void pwm_timer0_isr(void) __interrupt(1);
