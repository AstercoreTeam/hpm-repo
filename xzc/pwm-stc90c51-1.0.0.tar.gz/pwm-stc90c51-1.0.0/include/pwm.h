#pragma once
#include "hpm_dev.h"
#include <stdint.h>

void pwm_timer0_isr(void) __interrupt(1);
