#pragma once
#include <stdint.h>
#include "stc90c51_reg.h"

/* ========== P1 口 (P1.0 ~ P1.7) ========== */

void hpm_pin_P1_0_init(void);
void hpm_pin_P1_0_write(int level);
int  hpm_pin_P1_0_read(void);

void hpm_pin_P1_1_init(void);
void hpm_pin_P1_1_write(int level);
int  hpm_pin_P1_1_read(void);

void hpm_pin_P1_2_init(void);
void hpm_pin_P1_2_write(int level);
int  hpm_pin_P1_2_read(void);

void hpm_pin_P1_3_init(void);
void hpm_pin_P1_3_write(int level);
int  hpm_pin_P1_3_read(void);

void hpm_pin_P1_4_init(void);
void hpm_pin_P1_4_write(int level);
int  hpm_pin_P1_4_read(void);

void hpm_pin_P1_5_init(void);
void hpm_pin_P1_5_write(int level);
int  hpm_pin_P1_5_read(void);

void hpm_pin_P1_6_init(void);
void hpm_pin_P1_6_write(int level);
int  hpm_pin_P1_6_read(void);

void hpm_pin_P1_7_init(void);
void hpm_pin_P1_7_write(int level);
int  hpm_pin_P1_7_read(void);

/* ========== P3 口 (P3.0 ~ P3.7) ========== */

void hpm_pin_P3_0_init(void);
void hpm_pin_P3_0_write(int level);
int  hpm_pin_P3_0_read(void);

void hpm_pin_P3_1_init(void);
void hpm_pin_P3_1_write(int level);
int  hpm_pin_P3_1_read(void);

void hpm_pin_P3_2_init(void);
void hpm_pin_P3_2_write(int level);
int  hpm_pin_P3_2_read(void);

void hpm_pin_P3_3_init(void);
void hpm_pin_P3_3_write(int level);
int  hpm_pin_P3_3_read(void);

void hpm_pin_P3_4_init(void);
void hpm_pin_P3_4_write(int level);
int  hpm_pin_P3_4_read(void);

void hpm_pin_P3_5_init(void);
void hpm_pin_P3_5_write(int level);
int  hpm_pin_P3_5_read(void);

void hpm_pin_P3_6_init(void);
void hpm_pin_P3_6_write(int level);
int  hpm_pin_P3_6_read(void);

void hpm_pin_P3_7_init(void);
void hpm_pin_P3_7_write(int level);
int  hpm_pin_P3_7_read(void);

/* 输入读取走位操作，保证与 GPIO PinState 合并路径一致。 */
#ifndef HPM_PIN_IMPL
#define hpm_pin_P1_0_read() (P1_0)
#define hpm_pin_P1_1_read() (P1_1)
#define hpm_pin_P1_2_read() (P1_2)
#define hpm_pin_P1_3_read() (P1_3)
#define hpm_pin_P1_4_read() (P1_4)
#define hpm_pin_P1_5_read() (P1_5)
#define hpm_pin_P1_6_read() (P1_6)
#define hpm_pin_P1_7_read() (P1_7)
#define hpm_pin_P3_0_read() (P3_0)
#define hpm_pin_P3_1_read() (P3_1)
#define hpm_pin_P3_2_read() (P3_2)
#define hpm_pin_P3_3_read() (P3_3)
#define hpm_pin_P3_4_read() (P3_4)
#define hpm_pin_P3_5_read() (P3_5)
#define hpm_pin_P3_6_read() (P3_6)
#define hpm_pin_P3_7_read() (P3_7)
#endif
