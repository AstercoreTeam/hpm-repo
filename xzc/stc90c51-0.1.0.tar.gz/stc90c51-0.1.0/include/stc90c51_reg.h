#pragma once

/*
 * STC90C51 寄存器定义（SDCC 语法）
 *
 * 覆盖：
 *   - 标准 8051 SFR（P0~P3、SP、DPL/DPH、PCON、TCON、TMOD、TL0/1、TH0/1、
 *     SCON、SBUF、IE、IP、PSW、ACC、B）
 *   - 位定义（P1/P3 全部，IE、TCON、SCON、PSW 常用位）
 *   - STC89/90 扩展：AUXR（6T/12T）、WDT_CONTR（看门狗）
 *
 * 注意：STC90C51 的时钟源、6T/12T 模式、看门狗使能，
 *      通常在 STC-ISP 烧录软件里配置，运行时也可通过 AUXR 修改。
 */

/* ==================== 字节 SFR ==================== */

/* P0~P3 */
__sfr __at (0x80) P0;
__sfr __at (0x90) P1;
__sfr __at (0xA0) P2;
__sfr __at (0xB0) P3;

/* 堆栈指针 */
__sfr __at (0x81) SP;

/* 数据指针 */
__sfr __at (0x82) DPL;
__sfr __at (0x83) DPH;

/* 电源控制 */
__sfr __at (0x87) PCON;

/* 定时器控制 / 模式 */
__sfr __at (0x88) TCON;
__sfr __at (0x89) TMOD;
__sfr __at (0x8A) TL0;
__sfr __at (0x8B) TL1;
__sfr __at (0x8C) TH0;
__sfr __at (0x8D) TH1;

/* 串口 */
__sfr __at (0x98) SCON;
__sfr __at (0x99) SBUF;

/* 中断使能 / 优先级 */
__sfr __at (0xA8) IE;
__sfr __at (0xB8) IP;

/* 程序状态字 / 累加器 / B */
__sfr __at (0xD0) PSW;
__sfr __at (0xE0) ACC;
__sfr __at (0xF0) B;

/* STC89/90 扩展 */
__sfr __at (0x8E) AUXR;        /* 辅助寄存器：6T/12T 模式等 */
__sfr __at (0xC1) WDT_CONTR;   /* 看门狗控制（STC89/90 系列） */

/* ==================== 位定义 ==================== */

/* ---- P1 口 ---- */
__sbit __at (0x90) P1_0;
__sbit __at (0x91) P1_1;
__sbit __at (0x92) P1_2;
__sbit __at (0x93) P1_3;
__sbit __at (0x94) P1_4;
__sbit __at (0x95) P1_5;
__sbit __at (0x96) P1_6;
__sbit __at (0x97) P1_7;

/* ---- P3 口 ---- */
__sbit __at (0xB0) P3_0;
__sbit __at (0xB1) P3_1;
__sbit __at (0xB2) P3_2;
__sbit __at (0xB3) P3_3;
__sbit __at (0xB4) P3_4;
__sbit __at (0xB5) P3_5;
__sbit __at (0xB6) P3_6;
__sbit __at (0xB7) P3_7;

/* ---- TCON 位 ---- */
__sbit __at (0x88) IT0;   /* 外部中断 0 触发方式 */
__sbit __at (0x89) IE0;   /* 外部中断 0 标志 */
__sbit __at (0x8A) IT1;   /* 外部中断 1 触发方式 */
__sbit __at (0x8B) IE1;   /* 外部中断 1 标志 */
__sbit __at (0x8C) TR0;   /* 定时器 0 运行控制 */
__sbit __at (0x8D) TF0;   /* 定时器 0 溢出标志 */
__sbit __at (0x8E) TR1;   /* 定时器 1 运行控制 */
__sbit __at (0x8F) TF1;   /* 定时器 1 溢出标志 */

/* ---- IE 位 ---- */
__sbit __at (0xA8) EX0;   /* 外部中断 0 使能 */
__sbit __at (0xA9) ET0;   /* 定时器 0 中断使能 */
__sbit __at (0xAA) EX1;   /* 外部中断 1 使能 */
__sbit __at (0xAB) ET1;   /* 定时器 1 中断使能 */
__sbit __at (0xAC) ES;    /* 串口中断使能 */
__sbit __at (0xAF) EA;    /* 总中断使能 */

/* ---- SCON 位 ---- */
__sbit __at (0x98) RI;    /* 接收中断标志 */
__sbit __at (0x99) TI;    /* 发送中断标志 */
__sbit __at (0x9A) RB8;   /* 接收第 9 位 */
__sbit __at (0x9B) TB8;   /* 发送第 9 位 */
__sbit __at (0x9C) REN;   /* 接收使能 */
__sbit __at (0x9D) SM2;   /* 多机通信控制 */
__sbit __at (0x9E) SM1;   /* 串口模式 1 */
__sbit __at (0x9F) SM0;   /* 串口模式 0 */

/* ---- PSW 位 ---- */
__sbit __at (0xD0) P;     /* 奇偶标志 */
__sbit __at (0xD1) F1;    /* 用户标志 1 */
__sbit __at (0xD2) OV;    /* 溢出标志 */
__sbit __at (0xD3) RS0;   /* 寄存器组选择 0 */
__sbit __at (0xD4) RS1;   /* 寄存器组选择 1 */
__sbit __at (0xD5) F0;    /* 用户标志 0 */
__sbit __at (0xD6) AC;    /* 辅助进位 */
__sbit __at (0xD7) CY;    /* 进位 */

/* ==================== 常用位掩码（字节操作用） ==================== */

/* IE */
#define IE_EA   0x80
#define IE_ES   0x10
#define IE_ET1  0x08
#define IE_EX1  0x04
#define IE_ET0  0x02
#define IE_EX0  0x01

/* TCON */
#define TCON_TF1 0x80
#define TCON_TR1 0x40
#define TCON_TF0 0x20
#define TCON_TR0 0x10
#define TCON_IE1 0x08
#define TCON_IT1 0x04
#define TCON_IE0 0x02
#define TCON_IT0 0x01

/* TMOD */
#define TMOD_GATE1  0x80
#define TMOD_CT1    0x40
#define TMOD_M1_1   0x20
#define TMOD_M1_0   0x10
#define TMOD_GATE0  0x08
#define TMOD_CT0    0x04
#define TMOD_M0_1   0x02
#define TMOD_M0_0   0x01

/* SCON */
#define SCON_SM0 0x80
#define SCON_SM1 0x40
#define SCON_SM2 0x20
#define SCON_REN 0x10
#define SCON_TB8 0x08
#define SCON_RB8 0x04
#define SCON_TI  0x02
#define SCON_RI  0x01

/* AUXR（STC89/90） */
#define AUXR_T0X12  0x80   /* Timer0 6T 模式（1=6T，0=12T） */
#define AUXR_T1X12  0x40   /* Timer1 6T 模式 */
#define AUXR_UART_M0X6 0x20 /* 串口模式 0 波特率 6T */
#define AUXR_BRTx12 0x10
#define AUXR_S2SMOD 0x08
#define AUXR_EXTRAM 0x04   /* 扩展 RAM 使能 */
#define AUXR_T2X12  0x02

/* WDT_CONTR（STC89/90） */
#define WDT_ENABLE  0x20   /* 看门狗使能 */
#define WDT_CLR     0x10   /* 喂狗 */
#define WDT_IDLE    0x08   /* IDLE 模式看门狗 */
#define WDT_PS2     0x04
#define WDT_PS1     0x02
#define WDT_PS0     0x01
