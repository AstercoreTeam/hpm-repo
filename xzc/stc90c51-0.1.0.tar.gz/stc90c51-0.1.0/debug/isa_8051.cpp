// Copyright 2026 XueZicheng <xuezicheng842@outlook.com>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "mcus/instruction.h"
#include "mcus/isa_plugin.h"
#include "mcus/log.h"
#include <cstdio>
#include <memory>
#include <string>
#include <unordered_set>

namespace mcus {
namespace {

class Isa8051 : public InstructionSet {
public:
    explicit Isa8051(const Model& model) : model_(model) {
        code_space_ = model.arch_desc.reset_space.empty()
                          ? SpaceId("code")
                          : model.arch_desc.reset_space;
        iram_space_ = "iram";
        sfr_space_ = model.arch_desc.sp_reg_space.empty()
                         ? sfr_space_
                         : model.arch_desc.sp_reg_space;
        xram_space_ = "xram";
        for (const auto& e : model.isa_extensions)
            extensions_.insert(e);
    }

    bool has_ext(const std::string& name) const {
        return extensions_.count(name) > 0;
    }

    ExecResult execute(CpuRegisters& regs, MemoryBus& bus) override {
        ExecResult res;
        res.cycles = 1;

        Addr pc = regs.pc;
        uint8_t op = fetch(bus, pc);

        switch (op) {
            case 0x00: pc += 1; break;

            case 0x01: case 0x21: case 0x41: case 0x61:
            case 0x81: case 0xA1: case 0xC1: case 0xE1: {
                uint16_t target = ((pc + 2) & 0xF800) |
                                  ((op & 0xE0) << 3) |
                                  fetch(bus, pc + 1);
                pc = target;
                break;
            }

            case 0x02: {
                uint8_t b1 = fetch(bus, pc + 1);
                uint8_t b2 = fetch(bus, pc + 2);
                uint16_t a = (static_cast<uint16_t>(b1) << 8) | b2;
                pc = a;
                break;
            }

            case 0x03: {
                uint8_t a = read_acc(bus);
                a = static_cast<uint8_t>((a >> 1) | (a << 7));
                write_acc(bus, a);
                pc += 1;
                break;
            }

            case 0x04: {
                write_acc(bus, static_cast<uint8_t>(read_acc(bus) + 1));
                pc += 1;
                break;
            }

            case 0x05: {
                uint8_t addr = fetch(bus, pc + 1);
                direct_write(bus, addr,
                             static_cast<uint8_t>(direct_read(bus, addr) + 1));
                pc += 2;
                break;
            }

            case 0x06: case 0x07: {
                uint8_t ri = op & 0x01;
                uint8_t addr = reg_read(bus, ri);
                bus.write8(iram_space_, addr,
                           static_cast<uint8_t>(bus.read8(iram_space_, addr) + 1));
                pc += 1;
                break;
            }

            case 0x08: case 0x09: case 0x0A: case 0x0B:
            case 0x0C: case 0x0D: case 0x0E: case 0x0F: {
                uint8_t rn = op & 0x07;
                reg_write(bus, rn, static_cast<uint8_t>(reg_read(bus, rn) + 1));
                pc += 1;
                break;
            }

            case 0x10: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 2));
                bool set = bit_read(bus, bit_addr);
                if (set) {
                    bit_write(bus, bit_addr, false);
                    pc = static_cast<uint16_t>(pc + 3 + rel);
                } else {
                    pc += 3;
                }
                break;
            }

            case 0x11: case 0x31: case 0x51: case 0x71:
            case 0x91: case 0xB1: case 0xD1: case 0xF1: {
                uint16_t target = ((pc + 2) & 0xF800) |
                                  ((op & 0xE0) << 3) |
                                  fetch(bus, pc + 1);
                push(bus, static_cast<uint8_t>((pc + 2) & 0xFF));
                push(bus, static_cast<uint8_t>(((pc + 2) >> 8) & 0xFF));
                pc = target;
                break;
            }

            case 0x12: {
                uint8_t b1 = fetch(bus, pc + 1);
                uint8_t b2 = fetch(bus, pc + 2);
                uint16_t a = (static_cast<uint16_t>(b1) << 8) | b2;
                push(bus, static_cast<uint8_t>((pc + 3) & 0xFF));
                push(bus, static_cast<uint8_t>(((pc + 3) >> 8) & 0xFF));
                pc = a;
                break;
            }

            case 0x13: {
                uint8_t a = read_acc(bus);
                uint8_t cy = read_cy(bus);
                uint8_t new_cy = a & 0x01;
                a = static_cast<uint8_t>((a >> 1) | (cy << 7));
                write_cy(bus, new_cy);
                write_acc(bus, a);
                pc += 1;
                break;
            }

            case 0x14: {
                write_acc(bus, static_cast<uint8_t>(read_acc(bus) - 1));
                pc += 1;
                break;
            }

            case 0x15: {
                uint8_t addr = fetch(bus, pc + 1);
                direct_write(bus, addr,
                             static_cast<uint8_t>(direct_read(bus, addr) - 1));
                pc += 2;
                break;
            }

            case 0x16: case 0x17: {
                uint8_t ri = op & 0x01;
                uint8_t addr = reg_read(bus, ri);
                bus.write8(iram_space_, addr,
                           static_cast<uint8_t>(bus.read8(iram_space_, addr) - 1));
                pc += 1;
                break;
            }

            case 0x18: case 0x19: case 0x1A: case 0x1B:
            case 0x1C: case 0x1D: case 0x1E: case 0x1F: {
                uint8_t rn = op & 0x07;
                reg_write(bus, rn, static_cast<uint8_t>(reg_read(bus, rn) - 1));
                pc += 1;
                break;
            }

            case 0x20: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 2));
                if (bit_read(bus, bit_addr))
                    pc = static_cast<uint16_t>(pc + 3 + rel);
                else
                    pc += 3;
                break;
            }

            case 0x22: {
                uint8_t hi = pop(bus);
                uint8_t lo = pop(bus);
                pc = (static_cast<uint16_t>(hi) << 8) | lo;
                break;
            }

            case 0x23: {
                uint8_t a = read_acc(bus);
                a = static_cast<uint8_t>((a << 1) | (a >> 7));
                write_acc(bus, a);
                pc += 1;
                break;
            }

            case 0x24: case 0x25: {
                uint8_t src = (op == 0x24) ? fetch(bus, pc + 1)
                                            : direct_read(bus, fetch(bus, pc + 1));
                add_a(bus, src, false);
                pc += 2;
                break;
            }

            case 0x26: case 0x27: {
                uint8_t ri = op & 0x01;
                add_a(bus, bus.read8(iram_space_, reg_read(bus, ri)), false);
                pc += 1;
                break;
            }

            case 0x28: case 0x29: case 0x2A: case 0x2B:
            case 0x2C: case 0x2D: case 0x2E: case 0x2F: {
                add_a(bus, reg_read(bus, op & 0x07), false);
                pc += 1;
                break;
            }

            case 0x30: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 2));
                if (!bit_read(bus, bit_addr))
                    pc = static_cast<uint16_t>(pc + 3 + rel);
                else
                    pc += 3;
                break;
            }

            case 0x32: {
                // RETI：与 RET 相同的两次 pop，然后通知 CPU 恢复 IP
                uint8_t hi = pop(bus);
                uint8_t lo = pop(bus);
                pc = (static_cast<uint16_t>(hi) << 8) | lo;
                bus.on_reti();
                break;
            }

            case 0x33: {
                uint8_t a = read_acc(bus);
                uint8_t cy = read_cy(bus);
                uint8_t new_cy = (a >> 7) & 0x01;
                a = static_cast<uint8_t>((a << 1) | cy);
                write_cy(bus, new_cy);
                write_acc(bus, a);
                pc += 1;
                break;
            }

            case 0x34: case 0x35: {
                uint8_t src = (op == 0x34) ? fetch(bus, pc + 1)
                                            : direct_read(bus, fetch(bus, pc + 1));
                add_a(bus, src, true);
                pc += 2;
                break;
            }

            case 0x36: case 0x37: {
                uint8_t ri = op & 0x01;
                add_a(bus, bus.read8(iram_space_, reg_read(bus, ri)), true);
                pc += 1;
                break;
            }

            case 0x38: case 0x39: case 0x3A: case 0x3B:
            case 0x3C: case 0x3D: case 0x3E: case 0x3F: {
                add_a(bus, reg_read(bus, op & 0x07), true);
                pc += 1;
                break;
            }

            case 0x40: {
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 1));
                if (read_cy(bus))
                    pc = static_cast<uint16_t>(pc + 2 + rel);
                else
                    pc += 2;
                break;
            }

            case 0x42: {
                uint8_t addr = fetch(bus, pc + 1);
                direct_write(bus, addr,
                             static_cast<uint8_t>(direct_read(bus, addr) | read_acc(bus)));
                pc += 2;
                break;
            }

            case 0x43: {
                uint8_t addr = fetch(bus, pc + 1);
                uint8_t imm = fetch(bus, pc + 2);
                direct_write(bus, addr,
                             static_cast<uint8_t>(direct_read(bus, addr) | imm));
                pc += 3;
                break;
            }

            case 0x44: {
                uint8_t imm = fetch(bus, pc + 1);
                write_acc(bus, static_cast<uint8_t>(read_acc(bus) | imm));
                pc += 2;
                break;
            }

            case 0x45: {
                uint8_t addr = fetch(bus, pc + 1);
                write_acc(bus, static_cast<uint8_t>(read_acc(bus) | direct_read(bus, addr)));
                pc += 2;
                break;
            }

            case 0x46: case 0x47: {
                uint8_t ri = op & 0x01;
                write_acc(bus, static_cast<uint8_t>(
                    read_acc(bus) | bus.read8(iram_space_, reg_read(bus, ri))));
                pc += 1;
                break;
            }

            case 0x48: case 0x49: case 0x4A: case 0x4B:
            case 0x4C: case 0x4D: case 0x4E: case 0x4F: {
                write_acc(bus, static_cast<uint8_t>(
                    read_acc(bus) | reg_read(bus, op & 0x07)));
                pc += 1;
                break;
            }

            case 0x50: {
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 1));
                if (!read_cy(bus))
                    pc = static_cast<uint16_t>(pc + 2 + rel);
                else
                    pc += 2;
                break;
            }

            case 0x52: {
                uint8_t addr = fetch(bus, pc + 1);
                direct_write(bus, addr,
                             static_cast<uint8_t>(direct_read(bus, addr) & read_acc(bus)));
                pc += 2;
                break;
            }

            case 0x53: {
                uint8_t addr = fetch(bus, pc + 1);
                uint8_t imm = fetch(bus, pc + 2);
                direct_write(bus, addr,
                             static_cast<uint8_t>(direct_read(bus, addr) & imm));
                pc += 3;
                break;
            }

            case 0x54: {
                uint8_t imm = fetch(bus, pc + 1);
                write_acc(bus, static_cast<uint8_t>(read_acc(bus) & imm));
                pc += 2;
                break;
            }

            case 0x55: {
                uint8_t addr = fetch(bus, pc + 1);
                write_acc(bus, static_cast<uint8_t>(read_acc(bus) & direct_read(bus, addr)));
                pc += 2;
                break;
            }

                        case 0x56: case 0x57: {
                uint8_t ri = op & 0x01;
                write_acc(bus, static_cast<uint8_t>(
                    read_acc(bus) & bus.read8(iram_space_, reg_read(bus, ri))));
                pc += 1;
                break;
            }

            case 0x58: case 0x59: case 0x5A: case 0x5B:
            case 0x5C: case 0x5D: case 0x5E: case 0x5F: {
                write_acc(bus, static_cast<uint8_t>(
                    read_acc(bus) & reg_read(bus, op & 0x07)));
                pc += 1;
                break;
            }

            case 0x60: {
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 1));
                if (read_acc(bus) == 0)
                    pc = static_cast<uint16_t>(pc + 2 + rel);
                else
                    pc += 2;
                break;
            }

            case 0x62: {
                uint8_t addr = fetch(bus, pc + 1);
                direct_write(bus, addr,
                             static_cast<uint8_t>(direct_read(bus, addr) ^ read_acc(bus)));
                pc += 2;
                break;
            }

            case 0x63: {
                uint8_t addr = fetch(bus, pc + 1);
                uint8_t imm = fetch(bus, pc + 2);
                direct_write(bus, addr,
                             static_cast<uint8_t>(direct_read(bus, addr) ^ imm));
                pc += 3;
                break;
            }

            case 0x64: {
                uint8_t imm = fetch(bus, pc + 1);
                write_acc(bus, static_cast<uint8_t>(read_acc(bus) ^ imm));
                pc += 2;
                break;
            }

            case 0x65: {
                uint8_t addr = fetch(bus, pc + 1);
                write_acc(bus, static_cast<uint8_t>(read_acc(bus) ^ direct_read(bus, addr)));
                pc += 2;
                break;
            }

            case 0x66: case 0x67: {
                uint8_t ri = op & 0x01;
                write_acc(bus, static_cast<uint8_t>(
                    read_acc(bus) ^ bus.read8(iram_space_, reg_read(bus, ri))));
                pc += 1;
                break;
            }

            case 0x68: case 0x69: case 0x6A: case 0x6B:
            case 0x6C: case 0x6D: case 0x6E: case 0x6F: {
                write_acc(bus, static_cast<uint8_t>(
                    read_acc(bus) ^ reg_read(bus, op & 0x07)));
                pc += 1;
                break;
            }

            case 0x70: {
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 1));
                if (read_acc(bus) != 0)
                    pc = static_cast<uint16_t>(pc + 2 + rel);
                else
                    pc += 2;
                break;
            }

            case 0x72: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                write_cy(bus, read_cy(bus) || bit_read(bus, bit_addr));
                pc += 2;
                break;
            }

            case 0x73: {
                uint16_t dptr = (read_dph(bus) << 8) | read_dpl(bus);
                pc = static_cast<uint16_t>(read_acc(bus) + dptr);
                break;
            }

            case 0x74: {
                write_acc(bus, fetch(bus, pc + 1));
                pc += 2;
                break;
            }

            case 0x75: {
                uint8_t addr = fetch(bus, pc + 1);
                uint8_t imm = fetch(bus, pc + 2);
                direct_write(bus, addr, imm);
                pc += 3;
                break;
            }

            case 0x76: case 0x77: {
                uint8_t ri = op & 0x01;
                uint8_t imm = fetch(bus, pc + 1);
                bus.write8(iram_space_, reg_read(bus, ri), imm);
                pc += 2;
                break;
            }

            case 0x78: case 0x79: case 0x7A: case 0x7B:
            case 0x7C: case 0x7D: case 0x7E: case 0x7F: {
                uint8_t rn = static_cast<uint8_t>(op & 0x07);
                uint8_t imm = fetch(bus, pc + 1);
                reg_write(bus, rn, imm);
                pc = static_cast<uint16_t>(pc + 2);
                break;
            }

            case 0x80: {
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 1));
                pc = static_cast<uint16_t>(pc + 2 + rel);
                break;
            }

            case 0x82: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                write_cy(bus, read_cy(bus) && bit_read(bus, bit_addr));
                pc += 2;
                break;
            }

            case 0x83: {
                Addr a = static_cast<Addr>(pc + 1 + read_acc(bus));
                write_acc(bus, bus.read8(code_space_, a));
                pc += 1;
                break;
            }

            case 0x84: {
                uint8_t a = read_acc(bus);
                uint8_t b = bus.read8(sfr_space_, 0xF0);
                if (b == 0) {
                    write_cy(bus, 1);
                    write_ov(bus, 1);
                } else {
                    write_acc(bus, static_cast<uint8_t>(a / b));
                    bus.write8(sfr_space_, 0xF0, static_cast<uint8_t>(a % b));
                    write_cy(bus, 0);
                    write_ov(bus, 0);
                }
                pc += 1;
                break;
            }

            case 0x85: {
                uint8_t src = fetch(bus, pc + 1);
                uint8_t dst = fetch(bus, pc + 2);
                direct_write(bus, dst, direct_read(bus, src));
                pc += 3;
                break;
            }

            case 0x86: case 0x87: {
                uint8_t ri = op & 0x01;
                uint8_t dst = fetch(bus, pc + 1);
                direct_write(bus, dst, bus.read8(iram_space_, reg_read(bus, ri)));
                pc += 2;
                break;
            }

            case 0x88: case 0x89: case 0x8A: case 0x8B:
            case 0x8C: case 0x8D: case 0x8E: case 0x8F: {
                uint8_t dst = fetch(bus, pc + 1);
                direct_write(bus, dst, reg_read(bus, op & 0x07));
                pc += 2;
                break;
            }

            case 0x90: {
                write_dph(bus, fetch(bus, pc + 1));
                write_dpl(bus, fetch(bus, pc + 2));
                pc += 3;
                break;
            }

            case 0x92: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                bit_write(bus, bit_addr, read_cy(bus));
                pc += 2;
                break;
            }

            case 0x93: {
                uint16_t dptr = (read_dph(bus) << 8) | read_dpl(bus);
                Addr a = static_cast<Addr>(dptr + read_acc(bus));
                write_acc(bus, bus.read8(code_space_, a));
                pc += 1;
                break;
            }

            case 0x94: case 0x95: {
                uint8_t src = (op == 0x94) ? fetch(bus, pc + 1)
                                            : direct_read(bus, fetch(bus, pc + 1));
                subb_a(bus, src);
                pc += 2;
                break;
            }

            case 0x96: case 0x97: {
                uint8_t ri = op & 0x01;
                subb_a(bus, bus.read8(iram_space_, reg_read(bus, ri)));
                pc += 1;
                break;
            }

            case 0x98: case 0x99: case 0x9A: case 0x9B:
            case 0x9C: case 0x9D: case 0x9E: case 0x9F: {
                subb_a(bus, reg_read(bus, op & 0x07));
                pc += 1;
                break;
            }

            case 0xA0: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                write_cy(bus, read_cy(bus) || !bit_read(bus, bit_addr));
                pc += 2;
                break;
            }

            case 0xA2: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                // MOV C,bit（ANL C,/bit 是 0xB0）
                write_cy(bus, bit_read(bus, bit_addr));
                pc += 2;
                break;
            }

            case 0xA3: {
                uint16_t dptr = (read_dph(bus) << 8) | read_dpl(bus);
                dptr = static_cast<uint16_t>(dptr + 1);
                write_dph(bus, static_cast<uint8_t>(dptr >> 8));
                write_dpl(bus, static_cast<uint8_t>(dptr & 0xFF));
                pc += 1;
                break;
            }

            case 0xA4: {
                uint16_t r = static_cast<uint16_t>(read_acc(bus)) *
                             bus.read8(sfr_space_, 0xF0);
                write_acc(bus, static_cast<uint8_t>(r & 0xFF));
                bus.write8(sfr_space_, 0xF0, static_cast<uint8_t>(r >> 8));
                write_cy(bus, 0);
                write_ov(bus, (r > 0xFF) ? 1 : 0);
                pc += 1;
                break;
            }

            case 0xA5: {
                if (!has_ext("wch_dptr1_movx")) {
                    res.halted = true;
                    break;
                }
                uint8_t xbus = bus.read8(sfr_space_, 0xA2);
                uint8_t saved_dps = xbus & 0x01;
                bus.write8(sfr_space_, 0xA2, static_cast<uint8_t>(xbus | 0x01));
                uint16_t dptr = (read_dph(bus) << 8) | read_dpl(bus);
                bus.write8(xram_space_, dptr, read_acc(bus));
                dptr = static_cast<uint16_t>(dptr + 1);
                write_dph(bus, static_cast<uint8_t>(dptr >> 8));
                write_dpl(bus, static_cast<uint8_t>(dptr & 0xFF));
                bus.write8(sfr_space_, 0xA2,
                           static_cast<uint8_t>((xbus & ~0x01) | saved_dps));
                pc += 1;
                break;
            }

            case 0xA6: case 0xA7: {
                uint8_t ri = op & 0x01;
                uint8_t src = fetch(bus, pc + 1);
                bus.write8(iram_space_, reg_read(bus, ri), direct_read(bus, src));
                pc += 2;
                break;
            }

            case 0xA8: case 0xA9: case 0xAA: case 0xAB:
            case 0xAC: case 0xAD: case 0xAE: case 0xAF: {
                reg_write(bus, op & 0x07, direct_read(bus, fetch(bus, pc + 1)));
                pc += 2;
                break;
            }

            case 0xB0: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                write_cy(bus, read_cy(bus) && !bit_read(bus, bit_addr));
                pc += 2;
                break;
            }

            case 0xB2: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                bit_write(bus, bit_addr, !bit_read(bus, bit_addr));
                pc += 2;
                break;
            }

            case 0xB3: write_cy(bus, !read_cy(bus)); pc += 1; break;

            case 0xB4: {
                uint8_t imm = fetch(bus, pc + 1);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 2));
                uint8_t a = read_acc(bus);
                write_cy(bus, a < imm ? 1 : 0);
                if (a != imm)
                    pc = static_cast<uint16_t>(pc + 3 + rel);
                else
                    pc += 3;
                break;
            }

            case 0xB5: {
                uint8_t addr = fetch(bus, pc + 1);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 2));
                uint8_t a = read_acc(bus);
                uint8_t d = direct_read(bus, addr);
                write_cy(bus, a < d ? 1 : 0);
                if (a != d)
                    pc = static_cast<uint16_t>(pc + 3 + rel);
                else
                    pc += 3;
                break;
            }

            case 0xB6: case 0xB7: {
                uint8_t ri = op & 0x01;
                uint8_t imm = fetch(bus, pc + 1);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 2));
                uint8_t v = bus.read8(iram_space_, reg_read(bus, ri));
                write_cy(bus, v < imm ? 1 : 0);
                if (v != imm)
                    pc = static_cast<uint16_t>(pc + 3 + rel);
                else
                    pc += 3;
                break;
            }

            case 0xB8: case 0xB9: case 0xBA: case 0xBB:
            case 0xBC: case 0xBD: case 0xBE: case 0xBF: {
                uint8_t rn = op & 0x07;
                uint8_t imm = fetch(bus, pc + 1);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 2));
                uint8_t v = reg_read(bus, rn);
                write_cy(bus, v < imm ? 1 : 0);
                if (v != imm)
                    pc = static_cast<uint16_t>(pc + 3 + rel);
                else
                    pc += 3;
                break;
            }

            case 0xC0: {
                uint8_t addr = fetch(bus, pc + 1);
                push(bus, direct_read(bus, addr));
                pc += 2;
                break;
            }

            case 0xC2: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                bit_write(bus, bit_addr, false);
                pc += 2;
                break;
            }

            case 0xC3: write_cy(bus, 0); pc += 1; break;

            case 0xC4: {
                uint8_t a = read_acc(bus);
                a = static_cast<uint8_t>((a << 4) | (a >> 4));
                write_acc(bus, a);
                pc += 1;
                break;
            }

            case 0xC5: {
                uint8_t addr = fetch(bus, pc + 1);
                uint8_t a = read_acc(bus);
                uint8_t d = direct_read(bus, addr);
                direct_write(bus, addr, a);
                write_acc(bus, d);
                pc += 2;
                break;
            }

            case 0xC6: case 0xC7: {
                uint8_t ri = op & 0x01;
                uint8_t addr = reg_read(bus, ri);
                uint8_t a = read_acc(bus);
                uint8_t d = bus.read8(iram_space_, addr);
                bus.write8(iram_space_, addr, a);
                write_acc(bus, d);
                pc += 1;
                break;
            }

            case 0xC8: case 0xC9: case 0xCA: case 0xCB:
            case 0xCC: case 0xCD: case 0xCE: case 0xCF: {
                uint8_t rn = op & 0x07;
                uint8_t a = read_acc(bus);
                uint8_t d = reg_read(bus, rn);
                reg_write(bus, rn, a);
                write_acc(bus, d);
                pc += 1;
                break;
            }

            case 0xD0: {
                uint8_t addr = fetch(bus, pc + 1);
                direct_write(bus, addr, pop(bus));
                pc += 2;
                break;
            }

            case 0xD2: {
                uint8_t bit_addr = fetch(bus, pc + 1);
                bit_write(bus, bit_addr, true);
                pc += 2;
                break;
            }

            case 0xD3: write_cy(bus, 1); pc += 1; break;

            case 0xD4: {
                uint8_t a = read_acc(bus);
                uint8_t cy = read_cy(bus) ? 1 : 0;
                bool ac = read_ac(bus);
                bool new_ac = false;
                if ((a & 0x0F) > 0x09 || ac) {
                    uint8_t lo = static_cast<uint8_t>(a + 0x06);
                    new_ac = ((lo & 0xF0) != (a & 0xF0));
                    a = lo;
                }
                if ((a & 0xF0) > 0x90 || cy) {
                    a = static_cast<uint8_t>(a + 0x60);
                    cy = 1;
                }
                write_cy(bus, cy);
                write_ac(bus, new_ac);
                write_acc(bus, a);
                pc += 1;
                break;
            }

            case 0xD5: {
                uint8_t addr = fetch(bus, pc + 1);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 2));
                uint8_t v = static_cast<uint8_t>(direct_read(bus, addr) - 1);
                direct_write(bus, addr, v);
                if (v != 0)
                    pc = static_cast<uint16_t>(pc + 3 + rel);
                else
                    pc += 3;
                break;
            }

            case 0xD6: case 0xD7: {
                uint8_t ri = op & 0x01;
                uint8_t addr = reg_read(bus, ri);
                uint8_t a = read_acc(bus);
                uint8_t d = bus.read8(iram_space_, addr);
                uint8_t new_a = static_cast<uint8_t>((a & 0xF0) | (d & 0x0F));
                uint8_t new_d = static_cast<uint8_t>((d & 0xF0) | (a & 0x0F));
                bus.write8(iram_space_, addr, new_d);
                write_acc(bus, new_a);
                pc += 1;
                break;
            }

            case 0xD8: case 0xD9: case 0xDA: case 0xDB:
            case 0xDC: case 0xDD: case 0xDE: case 0xDF: {
                uint8_t rn = static_cast<uint8_t>(op & 0x07);
                int8_t rel = static_cast<int8_t>(fetch(bus, pc + 1));
                uint8_t base = reg_bank_base(bus);
                uint8_t before = bus.read8(iram_space_, static_cast<Addr>(base + rn));
                uint8_t v = static_cast<uint8_t>(before - 1);
                reg_write(bus, rn, v);
                if (v != 0)
                    pc = static_cast<uint16_t>(pc + 2 + rel);
                else
                    pc += 2;
                break;
            }

            case 0xE0: {
                uint16_t dptr = (read_dph(bus) << 8) | read_dpl(bus);
                write_acc(bus, bus.read8(xram_space_, dptr));
                pc += 1;
                break;
            }

            case 0xE2: case 0xE3: {
                uint8_t ri = op & 0x01;
                uint8_t p2 = bus.read8(sfr_space_, 0xA0);
                uint16_t addr = (static_cast<uint16_t>(p2) << 8) | reg_read(bus, ri);
                write_acc(bus, bus.read8(xram_space_, addr));
                pc += 1;
                break;
            }

            case 0xE4: write_acc(bus, 0); pc += 1; break;

            case 0xE5: {
                uint8_t addr = fetch(bus, pc + 1);
                write_acc(bus, direct_read(bus, addr));
                pc += 2;
                break;
            }

            case 0xE6: case 0xE7: {
                uint8_t ri = op & 0x01;
                write_acc(bus, bus.read8(iram_space_, reg_read(bus, ri)));
                pc += 1;
                break;
            }

            case 0xE8: case 0xE9: case 0xEA: case 0xEB:
            case 0xEC: case 0xED: case 0xEE: case 0xEF: {
                write_acc(bus, reg_read(bus, op & 0x07));
                pc += 1;
                break;
            }

            case 0xF0: {
                uint16_t dptr = (read_dph(bus) << 8) | read_dpl(bus);
                bus.write8(xram_space_, dptr, read_acc(bus));
                pc += 1;
                break;
            }

            case 0xF2: case 0xF3: {
                uint8_t ri = op & 0x01;
                uint8_t p2 = bus.read8(sfr_space_, 0xA0);
                uint16_t addr = (static_cast<uint16_t>(p2) << 8) | reg_read(bus, ri);
                bus.write8(xram_space_, addr, read_acc(bus));
                pc += 1;
                break;
            }

            case 0xF4: {
                write_acc(bus, static_cast<uint8_t>(~read_acc(bus)));
                pc += 1;
                break;
            }

            case 0xF5: {
                uint8_t addr = fetch(bus, pc + 1);
                direct_write(bus, addr, read_acc(bus));
                pc += 2;
                break;
            }

            case 0xF6: case 0xF7: {
                uint8_t ri = op & 0x01;
                bus.write8(iram_space_, reg_read(bus, ri), read_acc(bus));
                pc += 1;
                break;
            }

            case 0xF8: case 0xF9: case 0xFA: case 0xFB:
            case 0xFC: case 0xFD: case 0xFE: case 0xFF: {
                reg_write(bus, op & 0x07, read_acc(bus));
                pc += 1;
                break;
            }

            default:
                MCUS_WARN("8051 opcode unimplemented: 0x" + std::to_string(op));
                res.halted = true;
                break;
        }

        regs.pc = pc;
        return res;
    }

private:
    const Model& model_;
    SpaceId code_space_;
    SpaceId iram_space_;
    SpaceId sfr_space_;
    SpaceId xram_space_;
    std::unordered_set<std::string> extensions_;

    uint8_t fetch(MemoryBus& bus, Addr addr) {
        return bus.fetch8(addr);
    }
    void push(MemoryBus& bus, uint8_t v) {
        uint8_t sp = static_cast<uint8_t>(
            bus.read8(model_.arch_desc.sp_reg_space, model_.arch_desc.sp_reg) + 1);
        bus.write8(model_.arch_desc.sp_reg_space, model_.arch_desc.sp_reg, sp);
        bus.write8(model_.arch_desc.sp_space, sp, v);
    }

    uint8_t pop(MemoryBus& bus) {
        uint8_t sp = bus.read8(model_.arch_desc.sp_reg_space, model_.arch_desc.sp_reg);
        uint8_t v = bus.read8(model_.arch_desc.sp_space, sp);
        bus.write8(model_.arch_desc.sp_reg_space, model_.arch_desc.sp_reg,
                   static_cast<uint8_t>(sp - 1));
        return v;
    }

    uint8_t read_acc(MemoryBus& bus) { return bus.read8(sfr_space_, 0xE0); }

    void write_acc(MemoryBus& bus, uint8_t v) {
        bus.write8(sfr_space_, 0xE0, v);
        uint8_t p = 0;
        for (int i = 0; i < 8; ++i) p ^= ((v >> i) & 1);
        uint8_t psw = bus.read8(sfr_space_, 0xD0);
        psw = static_cast<uint8_t>((psw & 0xFE) | p);
        bus.write8(sfr_space_, 0xD0, psw);
    }

    uint8_t read_dpl(MemoryBus& bus) { return bus.read8(sfr_space_, 0x82); }
    uint8_t read_dph(MemoryBus& bus) { return bus.read8(sfr_space_, 0x83); }
    void write_dpl(MemoryBus& bus, uint8_t v) { bus.write8(sfr_space_, 0x82, v); }
    void write_dph(MemoryBus& bus, uint8_t v) { bus.write8(sfr_space_, 0x83, v); }

    bool read_cy(MemoryBus& bus) { return (bus.read8(sfr_space_, 0xD0) & 0x80) != 0; }

    void write_cy(MemoryBus& bus, bool v) {
        uint8_t psw = bus.read8(sfr_space_, 0xD0);
        psw = static_cast<uint8_t>((psw & 0x7F) | (v ? 0x80 : 0));
        bus.write8(sfr_space_, 0xD0, psw);
    }

    bool read_ac(MemoryBus& bus) { return (bus.read8(sfr_space_, 0xD0) & 0x40) != 0; }

    void write_ac(MemoryBus& bus, bool v) {
        uint8_t psw = bus.read8(sfr_space_, 0xD0);
        psw = static_cast<uint8_t>((psw & 0xBF) | (v ? 0x40 : 0));
        bus.write8(sfr_space_, 0xD0, psw);
    }

    void write_ov(MemoryBus& bus, int v) {
        uint8_t psw = bus.read8(sfr_space_, 0xD0);
        psw = static_cast<uint8_t>((psw & 0xFB) | (v ? 0x04 : 0));
        bus.write8(sfr_space_, 0xD0, psw);
    }

    uint8_t reg_bank_base(MemoryBus& bus) {
        uint8_t psw = bus.read8(sfr_space_, 0xD0);
        return static_cast<uint8_t>((psw & 0x18) >> 3) * 8;
    }

    uint8_t reg_read(MemoryBus& bus, uint8_t rn) {
        return bus.read8(iram_space_, static_cast<Addr>(reg_bank_base(bus) + rn));
    }

    void reg_write(MemoryBus& bus, uint8_t rn, uint8_t v) {
        bus.write8(iram_space_, static_cast<Addr>(reg_bank_base(bus) + rn), v);
    }

    uint8_t direct_read(MemoryBus& bus, uint8_t addr) {
        if (addr < 0x80) return bus.read8(iram_space_, addr);
        return bus.read8(sfr_space_, addr);
    }

    void direct_write(MemoryBus& bus, uint8_t addr, uint8_t v) {
        if (addr < 0x80) bus.write8(iram_space_, addr, v);
        else bus.write8(sfr_space_, addr, v);
    }

    bool bit_read(MemoryBus& bus, uint8_t bit_addr) {
        SpaceId space; Addr byte_addr; uint8_t bit;
        if (!resolve_bit_addr(model_, bit_addr, space, byte_addr, bit))
            return false;
        bool v = ((bus.read8(space, byte_addr) >> bit) & 1) != 0;
        return v;
    }

    void bit_write(MemoryBus& bus, uint8_t bit_addr, bool v) {
        SpaceId space; Addr byte_addr; uint8_t bit;
        if (!resolve_bit_addr(model_, bit_addr, space, byte_addr, bit))
            return;
        uint8_t cur = bus.read8(space, byte_addr);
        if (v) cur |= static_cast<uint8_t>(1u << bit);
        else cur &= static_cast<uint8_t>(~(1u << bit));
        bus.write8(space, byte_addr, cur);
    }

    void add_a(MemoryBus& bus, uint8_t src, bool with_carry) {
        uint8_t a = read_acc(bus);
        uint8_t c = with_carry ? (read_cy(bus) ? 1 : 0) : 0;
        uint16_t r = static_cast<uint16_t>(
            static_cast<uint16_t>(a) + src + c);
        uint8_t result = static_cast<uint8_t>(r & 0xFF);
        write_cy(bus, (r > 0xFF) ? 1 : 0);
        write_ac(bus, (((a & 0x0F) + (src & 0x0F) + c) > 0x0F) ? 1 : 0);
        write_ov(bus, ((~(a ^ src) & (a ^ result) & 0x80) != 0) ? 1 : 0);
        write_acc(bus, result);
    }

    void subb_a(MemoryBus& bus, uint8_t src) {
        uint8_t a = read_acc(bus);
        uint8_t c = read_cy(bus) ? 1 : 0;
        int r = static_cast<int>(a) - src - c;
        uint8_t result = static_cast<uint8_t>(r & 0xFF);
        write_cy(bus, (r < 0) ? 1 : 0);
        write_ac(bus, (((a & 0x0F) - (src & 0x0F) - c) < 0) ? 1 : 0);
        write_ov(bus, ((((a ^ src) & (a ^ result)) & 0x80) != 0) ? 1 : 0);
        write_acc(bus, result);
    }

    // ---- 架构钩子 ----

    void reset(CpuRegisters& regs, MemoryBus& bus, const Model& model) override {
        regs.pc = model.arch_desc.reset_vector;
        regs.sp = model.arch_desc.initial_sp;

        const SpaceId sp_space = model.arch_desc.sp_reg_space.empty()
                                     ? sfr_space_
                                     : model.arch_desc.sp_reg_space;
        const Addr sp_reg = model.arch_desc.sp_reg != 0
                                ? model.arch_desc.sp_reg
                                : 0x81;
        bus.write8(sp_space, sp_reg,
                   static_cast<uint8_t>(model.arch_desc.initial_sp));
        ip_stack_.clear();
    }

    void save_context(CpuRegisters& regs, MemoryBus& bus,
                      const Model& model) override {
        const RegisterDesc* ip = model.find_register_by_name("IP");
        const SpaceId ip_space = ip ? ip->space : sfr_space_;
        const Addr ip_addr = ip ? ip->addr : 0xB8;
        ip_stack_.push_back(bus.read8(ip_space, ip_addr));

        const SpaceId sp_space = model.arch_desc.sp_reg_space.empty()
                                     ? sfr_space_
                                     : model.arch_desc.sp_reg_space;
        const Addr sp_reg = model.arch_desc.sp_reg != 0
                                ? model.arch_desc.sp_reg
                                : 0x81;
        const SpaceId stack_space = model.arch_desc.sp_space;

        uint8_t sp = bus.read8(sp_space, sp_reg);
        for (uint8_t i = 0; i < model.arch_desc.irq_push_bytes; ++i) {
            ++sp;
            bus.write8(stack_space, sp,
                       static_cast<uint8_t>((regs.pc >> (8 * i)) & 0xFF));
        }
        bus.write8(sp_space, sp_reg, sp);
        regs.sp = sp;
    }

    void restore_context(CpuRegisters& regs, MemoryBus& bus,
                         const Model& model) override {
        (void)regs;
        if (ip_stack_.empty()) return;
        const RegisterDesc* ip = model.find_register_by_name("IP");
        const SpaceId ip_space = ip ? ip->space : sfr_space_;
        const Addr ip_addr = ip ? ip->addr : 0xB8;
        bus.write8(ip_space, ip_addr, ip_stack_.back());
        ip_stack_.pop_back();
    }

    bool resolve_bit_addr(const Model& model, Addr bit_addr, SpaceId& space,
                          Addr& byte_addr, uint8_t& bit) const override {
        if (bit_addr < 0x80) {
            space = iram_space_;
            byte_addr = 0x20 + (bit_addr / 8);
            bit = static_cast<uint8_t>(bit_addr % 8);
            return model.find_region(space, byte_addr) != nullptr;
        }
        space = sfr_space_;
        byte_addr = bit_addr & 0xF8;
        bit = static_cast<uint8_t>(bit_addr & 0x07);
        return model.find_register(space, byte_addr) != nullptr;
    }

private:
    std::vector<uint8_t> ip_stack_;
};

} // namespace

// ---- 外部 ISA 动态库 ABI ----

extern "C" uint32_t mcus_isa_abi_version() {
    return kIsaAbiVersion;
}

extern "C" const char* mcus_isa_arch() {
    return "8051";
}

extern "C" InstructionSet* mcus_isa_create(const Model* model) {
    if (!model) return nullptr;
    return new Isa8051(*model);
}

extern "C" void mcus_isa_destroy(InstructionSet* isa) {
    delete isa;
}

} // namespace mcus