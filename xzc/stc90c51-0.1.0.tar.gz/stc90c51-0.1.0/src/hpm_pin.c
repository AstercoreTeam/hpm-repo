#define HPM_PIN_IMPL
#include "hpm_pin.h"
#include "stc90c51_reg.h"

/*
 * 8051 准双向口：作为输出时，写 0 拉低，写 1 拉高（弱上拉）。
 * 作为输入时，需先写 1。
 * init 默认将端口置高，以便作为输入使用或输出高电平。
 */
#define DEF_PIN(port, bit) \
void hpm_pin_##port##_##bit##_init(void) { \
    port |= (1 << bit); \
} \
void hpm_pin_##port##_##bit##_write(int level) { \
    if (level) port |=  (1 << bit); \
        else       port &= ~(1 << bit); \
} \
int hpm_pin_##port##_##bit##_read(void) { \
    return port##_##bit; \
}

DEF_PIN(P1, 0)
DEF_PIN(P1, 1)
DEF_PIN(P1, 2)
DEF_PIN(P1, 3)
DEF_PIN(P1, 4)
DEF_PIN(P1, 5)
DEF_PIN(P1, 6)
DEF_PIN(P1, 7)
DEF_PIN(P3, 0)
DEF_PIN(P3, 1)
DEF_PIN(P3, 2)
DEF_PIN(P3, 3)
DEF_PIN(P3, 4)
DEF_PIN(P3, 5)
DEF_PIN(P3, 6)
DEF_PIN(P3, 7)
