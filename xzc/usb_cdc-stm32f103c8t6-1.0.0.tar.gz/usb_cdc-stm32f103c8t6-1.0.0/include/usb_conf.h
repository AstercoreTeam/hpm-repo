#ifndef __USB_CONF_H
#define __USB_CONF_H

#define EP_NUM 4
#define BTABLE_ADDRESS 0x00
#define IMR_MSK (0x8000 | 0x1000 | 0x0800 | 0x2000 | 0x0200 | 0x0100 | 0x0400)

#endif