#ifndef __USB_LIB_H
#define __USB_LIB_H

#include <stdint.h>

// 引入芯片底层定义（提供寄存器地址、__IO 等）
#include "stm32f103c8t6.h"

// 兼容 Keil 的 __IO 宏 (GCC 下等效为 volatile)
#ifndef __IO
#define __IO volatile
#endif

#include "usb_type.h"
#include "usb_regs.h"
#include "usb_def.h"
#include "usb_core.h"
#include "usb_init.h"
#include "usb_sil.h"
#include "usb_mem.h"
#include "usb_int.h"

#endif /* __USB_LIB_H */