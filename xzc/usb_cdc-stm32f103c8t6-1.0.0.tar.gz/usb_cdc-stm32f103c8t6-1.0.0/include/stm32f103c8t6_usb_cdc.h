#pragma once

#include <stdint.h>
#include "stm32f103c8t6.h"
#include "hpm_dev.h"

// GCC 下 __code 映射为 const（放 Flash）
#ifndef __code
#define __code const
#endif

// CDC 接口声明
void CDC_init(void);
void CDC_write(char c);
char CDC_read(void);
uint8_t CDC_available(void);