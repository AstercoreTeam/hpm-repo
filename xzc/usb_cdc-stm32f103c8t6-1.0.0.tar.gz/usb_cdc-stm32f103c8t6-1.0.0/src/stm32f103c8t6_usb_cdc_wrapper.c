// HPM 适配层：把 CDC_* 函数包装成 <device>_<method>
#include "hpm_dev.h"
#include "usb_cdc.h"

#define HPM_CAT_(a, b) a##b
#define HPM_CAT(a, b)  HPM_CAT_(a, b)
#define HPM_FN(name)   HPM_CAT(DEVICE_NAME, HPM_CAT(_, name))

void HPM_FN(init)(void) {
    CDC_init();
}

void HPM_FN(write)(char c) {
    CDC_write(c);
}

uint8_t HPM_FN(available)(void) {
    return CDC_available();
}

char HPM_FN(read)(void) {
    return CDC_read();
}