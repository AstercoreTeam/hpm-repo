#include "usb_cdc.h"
#include "usb_lib.h"
#include "usb_pwr.h"
#include "usb_istr.h"
#include "usb_descr.h"
#include "stm32f103c8t6.h"

volatile uint8_t CDC_readByteCount = 0;
volatile uint8_t CDC_writeBusyFlag = 0;
volatile uint8_t CDC_controlLineState = 0;
CDC_LINE_CODING_TYPE CDC_lineCoding = { .baudrate = 115200, .stopbits = 0, .parity = 0, .databits = 8 };

void CDC_init(void) {
    RCC->APB1ENR |= RCC_APB1ENR_USBEN;
    *(volatile uint32_t*)(0x40005C00 + 0x40) = 0x0001;
    for (volatile uint32_t i = 0; i < 72000; i++);
    *(volatile uint32_t*)(0x40005C00 + 0x40) = 0;
    USB_Init();
    NVIC_EnableIRQ(USB_LP_CAN1_RX0_IRQn);
}

// 其他端点初始化暂不开放，只为测试枚举
void CDC_EP_init(void) { }
void CDC_EP2_OUT(void) { }
void CDC_EP3_IN(void) { }
void CDC_write(char c) { }
void CDC_flush(void) { }
char CDC_read(void) { return 0; }
uint8_t CDC_control(void) { return 0; }