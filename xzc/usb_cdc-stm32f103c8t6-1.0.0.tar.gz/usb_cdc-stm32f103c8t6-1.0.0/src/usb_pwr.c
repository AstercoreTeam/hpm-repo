#include "usb_lib.h"
#include "usb_pwr.h"

__IO uint32_t bDeviceState = UNCONNECTED;
__IO bool fSuspendEnabled = TRUE;
__IO uint32_t EP[8];

struct {
  __IO RESUME_STATE eState;
  __IO uint8_t bESOFcnt;
} ResumeS;

__IO uint32_t remotewakeupon = 0;

RESULT PowerOn(void) {
    uint16_t wRegVal;
    wRegVal = CNTR_FRES;
    _SetCNTR(wRegVal);

    wInterrupt_Mask = 0;
    _SetCNTR(wInterrupt_Mask);

    /* 强制加长延时，给主机充分的时间识别 */
    for (volatile uint32_t i = 0; i < 500000; i++); 

    _SetISTR(0);
    wInterrupt_Mask = CNTR_RESETM | CNTR_SUSPM | CNTR_WKUPM;
    _SetCNTR(wInterrupt_Mask);

    return USB_SUCCESS;
}

RESULT PowerOff() {
  _SetCNTR(CNTR_FRES);
  _SetISTR(0);
  _SetCNTR(CNTR_FRES + CNTR_PDWN);
  return USB_SUCCESS;
}

void Suspend(void) {
  uint32_t i = 0;
  uint16_t wCNTR;
  wCNTR = _GetCNTR();
  for (i = 0; i < 8; i++) EP[i] = _GetENDPOINT(i);
  wCNTR |= CNTR_RESETM;
  _SetCNTR(wCNTR);
  wCNTR |= CNTR_FRES;
  _SetCNTR(wCNTR);
  wCNTR &= ~CNTR_FRES;
  _SetCNTR(wCNTR);
  
  uint32_t timeout = 0xFFFFF;
  while (((_GetISTR() & ISTR_RESET) == 0) && (timeout--));
  _SetISTR((uint16_t)CLR_RESET);
  
  for (i = 0; i < 8; i++) _SetENDPOINT(i, EP[i]);
  wCNTR |= CNTR_FSUSP;
  _SetCNTR(wCNTR);
  wCNTR = _GetCNTR();
  wCNTR |= CNTR_LPMODE;
  _SetCNTR(wCNTR);
}

void Resume_Init(void) {
  uint16_t wCNTR;
  wCNTR = _GetCNTR();
  wCNTR &= (~CNTR_LPMODE);
  _SetCNTR(wCNTR);
  _SetCNTR(IMR_MSK);
}

void Resume(RESUME_STATE eResumeSetVal) {
  uint16_t wCNTR;
  if (eResumeSetVal != RESUME_ESOF) ResumeS.eState = eResumeSetVal;
  switch (ResumeS.eState) {
    case RESUME_EXTERNAL:
      if (remotewakeupon == 0) { Resume_Init(); ResumeS.eState = RESUME_OFF; }
      else ResumeS.eState = RESUME_ON;
      break;
    case RESUME_INTERNAL:
      Resume_Init(); ResumeS.eState = RESUME_START; remotewakeupon = 1;
      break;
    case RESUME_LATER:
      ResumeS.bESOFcnt = 2; ResumeS.eState = RESUME_WAIT;
      break;
    case RESUME_WAIT:
      ResumeS.bESOFcnt--;
      if (ResumeS.bESOFcnt == 0) ResumeS.eState = RESUME_START;
      break;
    case RESUME_START:
      wCNTR = _GetCNTR();
      wCNTR |= CNTR_RESUME;
      _SetCNTR(wCNTR);
      ResumeS.eState = RESUME_ON;
      ResumeS.bESOFcnt = 10;
      break;
    case RESUME_ON:
      ResumeS.bESOFcnt--;
      if (ResumeS.bESOFcnt == 0) {
        wCNTR = _GetCNTR();
        wCNTR &= (~CNTR_RESUME);
        _SetCNTR(wCNTR);
        ResumeS.eState = RESUME_OFF;
        remotewakeupon = 0;
      }
      break;
    default:
      ResumeS.eState = RESUME_OFF;
      break;
  }
}