#include "time.h"
#include "stc90c51_reg.h"

#define HPM_CAT_(a, b) a##b
#define HPM_CAT(a, b)  HPM_CAT_(a, b)
#define HPM_FN(name)   HPM_CAT(DEVICE_NAME, HPM_CAT(_, name))

#define T_CYCLES_PER_MS ((unsigned long)1000UL * (unsigned long)(osc_hz) / (unsigned long)(clock_mode) / 1000000UL)
#define T_RELOAD ((unsigned int)(65536UL - T_CYCLES_PER_MS))
#define T_RELOAD_H  ((unsigned char)(T_RELOAD >> 8))
#define T_RELOAD_L  ((unsigned char)(T_RELOAD & 0xFF))

/* 【核心修复】：变量名拼上实例名，防止多次编译冲突 */
static volatile unsigned int HPM_FN(s_ms_ticks) = 0;
static void (*HPM_FN(s_callback))(void) = 0;

/* 【核心修复】：中断函数名拼上实例名，例如 app_delay_timer1_isr */
#if (timer_id == 0)
void HPM_CALL(time, timer0_isr)(void) __interrupt(1) {
    TH0 = T_RELOAD_H; TL0 = T_RELOAD_L;
    HPM_FN(s_ms_ticks)++;
    if (HPM_FN(s_callback)) HPM_FN(s_callback)();
}
#elif (timer_id == 1)
void HPM_CALL(time, timer1_isr)(void) __interrupt(3) {
    TH1 = T_RELOAD_H; TL1 = T_RELOAD_L;
    HPM_FN(s_ms_ticks)++;
    if (HPM_FN(s_callback)) HPM_FN(s_callback)();
}
#endif

int HPM_FN(init)(void) {
    HPM_FN(s_ms_ticks) = 0;
    HPM_FN(s_callback) = 0;

    #if (timer_id == 0)
    TMOD = (TMOD & 0xF0) | 0x01;
    TH0 = T_RELOAD_H; TL0 = T_RELOAD_L;
    IE |= 0x82; TCON |= 0x10;
    #elif (timer_id == 1)
    TMOD = (TMOD & 0x0F) | 0x10;
    TH1 = T_RELOAD_H; TL1 = T_RELOAD_L;
    IE |= 0x88; TCON |= 0x40;
    #endif
    return 0;
}

void HPM_FN(on_tick)(void (*callback)(void)) {
    HPM_FN(s_callback) = callback;
}
void HPM_FN(delay_ms)(unsigned int ms) {
    unsigned int start = HPM_FN(s_ms_ticks);
    while (1) {
        unsigned int current = HPM_FN(s_ms_ticks);
        if ((current - start) >= ms) break;
    }
}
