#pragma once
#include "hpm_dev.h"
#include "config.h"

/* 用宏把中断函数名也加上前缀 */
#define HPM_CAT_(a, b) a##b
#define HPM_CAT(a, b)  HPM_CAT_(a, b)
#define HPM_CALL(prefix, method)  HPM_CAT(prefix, HPM_CAT(_, method))

#if (timer_id == 0)
void HPM_CALL(time, timer0_isr)(void) __interrupt(1);
#elif (timer_id == 1)
void HPM_CALL(time, timer1_isr)(void) __interrupt(3);
#endif
