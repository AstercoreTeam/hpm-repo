# LED（gpio 驱动）虚拟设备脚本。
#
# 输出通道 power(bool) -> 灯珠发光 + 点光源。
# props.color 可选：red / green / blue / yellow / white / orange / purple / cyan，或 #rrggbb。
extends "res://sdk/virtual_device.gd"

const COLOR_NAMES := {
	"red": Color(0.9, 0.08, 0.08),
	"green": Color(0.1, 0.9, 0.25),
	"blue": Color(0.12, 0.35, 1.0),
	"yellow": Color(1.0, 0.85, 0.1),
	"white": Color(1.0, 0.96, 0.88),
	"orange": Color(1.0, 0.45, 0.08),
	"purple": Color(0.65, 0.2, 1.0),
	"cyan": Color(0.1, 0.9, 0.9),
}

var _emissive: Array[MeshInstance3D] = []
var _light: OmniLight3D
var _color := Color(0.9, 0.08, 0.08)
var _power := false

func _on_bind(ctx: Dictionary) -> void:
	var props: Dictionary = ctx.get("props", {})
	_color = _parse_color(String(props.get("color", "red")))
	var body := get_model_node("LedBody")
	if body == null:
		body = get_model_node("Body")
	if body != null:
		_collect_meshes(body, _emissive)
	else:
		_collect_meshes(model, _emissive)

	_light = OmniLight3D.new()
	_light.name = "Glow"
	_light.light_color = _color
	_light.omni_range = 1.4
	_light.light_energy = 0.0
	if model != null:
		_light.position = Vector3(0.0, 0.15, 0.0)
		model.add_child(_light)
	_apply(false)
	log_info("LED 已绑定，颜色 %s" % _color.to_html(false))

func _on_values(values: Dictionary) -> void:
	_apply(bool(values.get("power", false)))

func _on_session_stop() -> void:
	_apply(false)

func _apply(on: bool) -> void:
	_power = on
	for mesh: MeshInstance3D in _emissive:
		var material := StandardMaterial3D.new()
		material.albedo_color = _color.darkened(0.65) if not on else _color
		material.roughness = 0.25
		material.emission_enabled = true
		material.emission = _color
		material.emission_energy_multiplier = 2.2 if on else 0.0
		mesh.material_override = material
	if _light != null:
		_light.light_energy = 1.6 if on else 0.0

func _collect_meshes(node: Node, out: Array[MeshInstance3D]) -> void:
	if node is MeshInstance3D:
		out.append(node as MeshInstance3D)
	for child in node.get_children():
		_collect_meshes(child, out)

func _parse_color(text: String) -> Color:
	var key := text.strip_edges().to_lower()
	if COLOR_NAMES.has(key):
		return COLOR_NAMES[key]
	if key.begins_with("#") and Color.html_is_valid(key):
		return Color.html(key)
	return COLOR_NAMES["red"]
