#pragma once
#ifndef HPM_DEV_MACROS
#define HPM_DEV_MACROS
#include "hpm_dev.h"
#endif
#include "hpm_pin.h"
